#!/usr/bin/env python3
"""Modo Aula do Tualali OS.

Roda na sessao do aluno (inicio automatico). Fica procurando os beacons Bluetooth da escola:
- passou o computador perto do beacon a 1a vez  -> Modo Aula (so a Area do Estudante: Livro,
  Caderno e Atividades, em tela cheia e travada)
- passou de novo                                -> volta tudo ao normal (o contador zera)
Depois de uma troca, o beacon e ignorado por PAUSA segundos e o computador precisa se afastar
antes de contar de novo (evita trocar duas vezes sem querer). O modo continua apos reiniciar.

Configuracao: /etc/tualali/escola.conf
  TUALALI_ESCOLA_URL="https://tualalios.com.br"   endereco da plataforma da escola
  TUALALI_BEACONS=""        beacons extras aceitos sem internet (separados por espaco)
  TUALALI_RSSI_MINIMO=-60   sinal minimo (dBm) para contar como "passou perto"
  TUALALI_PAUSA=30          segundos minimos entre duas trocas

Linha de comando:
  tualali-modo-aula                  (servico; iniciado sozinho no login)
  tualali-modo-aula --status         mostra modo, codigo do computador e beacons
  tualali-modo-aula --simular ID     simula a passagem pelo beacon ID (testes sem o aparelho)
"""
import json
import os
import shlex
import subprocess
import sys
import threading
import time
import urllib.request

CONF = "/etc/tualali/escola.conf"
ESTADO_DIR = os.path.join(os.environ.get("XDG_STATE_HOME", os.path.expanduser("~/.local/state")), "tualali")
ESTADO = os.path.join(ESTADO_DIR, "modo-aula.json")
_RUN = os.environ.get("XDG_RUNTIME_DIR", "")
SIMULAR = os.path.join(_RUN if os.path.isdir(_RUN) else ESTADO_DIR, "tualali-modo-aula-simular")
APP_ESTUDANTE = ["/usr/bin/python3", "/usr/lib/tualali/area_estudante.py", "--modo-aula"]

# (schema, chave, valor no Modo Aula): so a Area do Estudante na barra e sem atalhos de fuga
TRAVAS = [
    ("org.gnome.shell", "favorite-apps", "['tualali-estudante.desktop']"),
    ("org.gnome.mutter", "overlay-key", "''"),
    ("org.gnome.desktop.interface", "enable-hot-corners", "false"),
    ("org.gnome.shell.keybindings", "toggle-overview", "@as []"),
    ("org.gnome.shell.keybindings", "toggle-application-view", "@as []"),
    ("org.gnome.shell.keybindings", "toggle-quick-settings", "@as []"),
    ("org.gnome.shell.keybindings", "toggle-message-tray", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "switch-applications", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "switch-applications-backward", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "switch-windows", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "switch-windows-backward", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "switch-group", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "cycle-windows", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "panel-run-dialog", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "minimize", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "close", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "toggle-fullscreen", "@as []"),
    ("org.gnome.settings-daemon.plugins.media-keys", "terminal", "@as []"),
    ("org.gnome.settings-daemon.plugins.media-keys", "home", "@as []"),
    ("org.gnome.settings-daemon.plugins.media-keys", "www", "@as []"),
]


def ler_conf(caminho=CONF):
    c = {"TUALALI_ESCOLA_URL": "", "TUALALI_BEACONS": "", "TUALALI_RSSI_MINIMO": "-60", "TUALALI_PAUSA": "30"}
    try:
        with open(caminho) as f:
            for linha in f:
                linha = linha.strip()
                if linha and not linha.startswith("#") and "=" in linha:
                    k, v = linha.split("=", 1)
                    v = shlex.split(v)[0] if v.strip() else ""
                    c[k.strip()] = v
    except OSError:
        pass
    return c


def normalizar(ident):
    return (ident or "").strip().lower()


class Detector:
    """Maquina de estados da passagem pelo beacon (sem dependencias, testavel)."""

    def __init__(self, rssi_minimo=-60, pausa=30, afastar=8):
        self.rssi_minimo, self.pausa, self.afastar = rssi_minimo, pausa, afastar
        self.perto = False
        self.ultimo_perto = 0.0
        self.ultima_troca = -1e9

    def ver(self, rssi, agora):
        """Recebe uma leitura de um beacon da escola. Devolve True quando deve trocar o modo."""
        if rssi is None or rssi < self.rssi_minimo:
            return False
        ja_estava = self.perto
        self.perto, self.ultimo_perto = True, agora
        if ja_estava or agora - self.ultima_troca < self.pausa:
            return False
        self.ultima_troca = agora
        return True

    def tique(self, agora):
        if self.perto and agora - self.ultimo_perto > self.afastar:
            self.perto = False


class Estado:
    def __init__(self, caminho=ESTADO):
        self.caminho = caminho
        try:
            with open(caminho) as f:
                self.d = json.load(f)
        except (OSError, ValueError):
            self.d = {}
        self.d.setdefault("modo", "livre")

    def __getitem__(self, k):
        return self.d.get(k)

    def __setitem__(self, k, v):
        self.d[k] = v
        self.salvar()

    def salvar(self):
        os.makedirs(os.path.dirname(self.caminho), exist_ok=True)
        tmp = self.caminho + ".tmp"
        with open(tmp, "w") as f:
            json.dump(self.d, f, indent=1)
        os.replace(tmp, self.caminho)


def gsettings(*args):
    r = subprocess.run(["gsettings"] + list(args), capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None


class Trava:
    """Aplica/desfaz as travas do GNOME guardando os valores originais no estado."""

    def __init__(self, estado, gs=gsettings):
        self.estado, self.gs = estado, gs

    def entrar(self):
        salvo = self.estado["salvo"] or {}
        for schema, chave, valor in TRAVAS:
            k = schema + " " + chave
            if k not in salvo:
                atual = self.gs("get", schema, chave)
                if atual is None:          # chave nao existe nesta versao do GNOME
                    continue
                salvo[k] = atual
        self.estado["salvo"] = salvo       # grava ANTES de mudar (sobrevive a queda de energia)
        for schema, chave, valor in TRAVAS:
            if schema + " " + chave in salvo:
                self.gs("set", schema, chave, valor)

    def sair(self):
        salvo = self.estado["salvo"] or {}
        for k, v in salvo.items():
            schema, chave = k.split(" ", 1)
            if self.gs("set", schema, chave, v) is None:
                self.gs("reset", schema, chave)
        self.estado["salvo"] = None


class Plataforma:
    """Conversa com a plataforma da escola (registrar, beacons, eventos)."""

    def __init__(self, url, estado):
        self.url, self.estado = url.rstrip("/"), estado

    def _post(self, caminho, dados, tempo=15):
        req = urllib.request.Request(self.url + caminho, data=json.dumps(dados).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=tempo) as r:
            return json.loads(r.read().decode())

    def registrar(self):
        if self.estado["token"] or not self.url:
            return
        r = self._post("/api/dispositivo/registrar", {"nome": os.uname().nodename})
        self.estado.d.update(token=r["token"], codigo=r["codigo"])
        self.estado.salvar()

    def beacons(self):
        r = self._post("/api/dispositivo/beacons", {"token": self.estado["token"]})
        self.estado["beacons"] = r["beacons"]
        return r["beacons"]

    def evento(self, beacon, modo):
        r = self._post("/api/dispositivo/evento", {"token": self.estado["token"], "beacon": beacon, "modo": modo})
        self.estado.d.update(codigo=r.get("codigo"), aluno=r.get("aluno"))
        self.estado.salvar()
        return r

    def url_estudante(self, aba="livros"):
        if not (self.url and self.estado["token"]):
            return None
        return "%s/estudante/entrar?dispositivo=%s&aba=%s" % (self.url, self.estado["token"], aba)


def notificar(titulo, texto):
    try:
        subprocess.Popen(["notify-send", "-i", "tualali-logo", titulo, texto])
    except OSError:
        pass


class ModoAula:
    def __init__(self, conf=None, estado=None, trava=None, abrir_app=None):
        self.conf = conf or ler_conf()
        self.estado = estado or Estado()
        self.trava = trava or Trava(self.estado)
        self.plat = Plataforma(self.conf["TUALALI_ESCOLA_URL"], self.estado)
        self.detector = Detector(int(self.conf["TUALALI_RSSI_MINIMO"]), int(self.conf["TUALALI_PAUSA"]))
        self.abrir_app = abrir_app or (lambda: subprocess.Popen(APP_ESTUDANTE))
        self.app = None
        self.trocas = 0

    def conhecidos(self):
        lista = (self.estado["beacons"] or []) + self.conf["TUALALI_BEACONS"].split()
        return {normalizar(b) for b in lista if b}

    def leitura(self, idents, rssi, agora=None):
        """Leitura do Bluetooth: idents = identificadores do aparelho (endereco, iBeacon)."""
        conhecidos = self.conhecidos()
        achado = next((i for i in idents if normalizar(i) in conhecidos), None)
        if achado and self.detector.ver(rssi, agora if agora is not None else time.monotonic()):
            self.trocar(achado)
            return True
        return False

    def trocar(self, beacon):
        self.trocas += 1
        if self.estado["modo"] == "aula":
            self.sair_aula()
        else:
            self.entrar_aula()
        threading.Thread(target=self._avisar_plataforma, args=(beacon, self.estado["modo"]), daemon=True).start()

    def _avisar_plataforma(self, beacon, modo):
        try:
            self.plat.registrar()
            self.plat.evento(beacon, modo)
        except Exception as e:  # noqa: BLE001 - sem internet o Modo Aula funciona igual
            print("plataforma indisponivel:", e, file=sys.stderr)

    def entrar_aula(self):
        self.trava.entrar()
        self.estado["modo"] = "aula"
        notificar("Modo Aula", "Livro, Caderno e Atividades liberados. Passe pelo beacon de novo para sair.")
        self.garantir_app()

    def sair_aula(self):
        self.estado["modo"] = "livre"
        self.trava.sair()
        if self.app and self.app.poll() is None:
            self.app.terminate()
        self.app = None
        notificar("Modo Aula encerrado", "Todos os aplicativos foram liberados.")

    def garantir_app(self):
        """No Modo Aula a Area do Estudante fica sempre aberta (reabre se for fechada)."""
        if self.estado["modo"] == "aula" and (self.app is None or self.app.poll() is not None):
            self.app = self.abrir_app()

    def atualizar_beacons(self):
        try:
            self.plat.registrar()
            self.plat.beacons()
        except Exception as e:  # noqa: BLE001
            print("nao foi possivel atualizar os beacons:", e, file=sys.stderr)

    def simulacoes(self):
        try:
            with open(SIMULAR) as f:
                ids = [l.strip() for l in f if l.strip()]
            os.remove(SIMULAR)
        except OSError:
            return
        for i in ids:
            self.detector.perto = False
            self.detector.ultima_troca = -1e9
            self.leitura([i], 0)


class ScannerBLE:
    """Le os anuncios Bluetooth LE pelo BlueZ (D-Bus do sistema), sem programas extras."""

    def __init__(self, ao_ler):
        from gi.repository import Gio, GLib
        self.Gio, self.GLib = Gio, GLib
        self.ao_ler = ao_ler
        self.bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        self.bus.signal_subscribe("org.bluez", "org.freedesktop.DBus.ObjectManager", "InterfacesAdded", None, None,
                                  Gio.DBusSignalFlags.NONE, self._adicionado)
        self.bus.signal_subscribe("org.bluez", "org.freedesktop.DBus.Properties", "PropertiesChanged", None,
                                  "org.bluez.Device1", Gio.DBusSignalFlags.MATCH_ARG0_NAMESPACE, self._mudou)

    def _chamar(self, caminho, iface, metodo, args=None, tipo=None):
        return self.bus.call_sync("org.bluez", caminho, iface, metodo, args,
                                  self.GLib.VariantType.new(tipo) if tipo else None,
                                  self.Gio.DBusCallFlags.NONE, 10000, None)

    def manter(self):
        """Liga a busca no adaptador (repetido periodicamente: outro programa pode desligar)."""
        V = self.GLib.Variant
        try:
            objs = self._chamar("/", "org.freedesktop.DBus.ObjectManager", "GetManagedObjects",
                                tipo="(a{oa{sa{sv}}})").unpack()[0]
        except Exception as e:  # noqa: BLE001 - sem Bluetooth / BlueZ parado
            print("Bluetooth indisponivel:", e, file=sys.stderr)
            return True
        for caminho, ifaces in objs.items():
            ad = ifaces.get("org.bluez.Adapter1")
            if not ad:
                continue
            try:
                if not ad.get("Powered"):
                    self._chamar(caminho, "org.freedesktop.DBus.Properties", "Set",
                                 V("(ssv)", ("org.bluez.Adapter1", "Powered", V("b", True))))
                if not ad.get("Discovering"):
                    self._chamar(caminho, "org.bluez.Adapter1", "SetDiscoveryFilter",
                                 V("(a{sv})", ({"Transport": V("s", "le"), "DuplicateData": V("b", True)},)))
                    self._chamar(caminho, "org.bluez.Adapter1", "StartDiscovery")
            except Exception as e:  # noqa: BLE001
                print("busca Bluetooth:", e, file=sys.stderr)
        return True

    def _adicionado(self, _c, _s, _caminho, _i, _sinal, params):
        caminho, ifaces = params.unpack()
        if "org.bluez.Device1" in ifaces:
            self._processar(ifaces["org.bluez.Device1"])

    def _mudou(self, _c, _s, caminho, _i, _sinal, params):
        iface, mudou, _inv = params.unpack()
        if iface == "org.bluez.Device1" and ("RSSI" in mudou or "ManufacturerData" in mudou):
            try:
                props = self._chamar(caminho, "org.freedesktop.DBus.Properties", "GetAll",
                                     self.GLib.Variant("(s)", ("org.bluez.Device1",)), "(a{sv})").unpack()[0]
            except Exception:  # noqa: BLE001
                return
            props.update(mudou)
            self._processar(props)

    def _processar(self, props):
        idents = identificadores(props)
        if idents and props.get("RSSI") is not None:
            self.ao_ler(idents, int(props["RSSI"]))


def identificadores(props):
    """Endereco do aparelho e, se for iBeacon, 'uuid:major:minor'."""
    ids = []
    if props.get("Address"):
        ids.append(str(props["Address"]).upper())
    md = props.get("ManufacturerData") or {}
    dados = md.get(0x004C)
    if dados is not None:
        b = bytes(dados)
        if len(b) >= 22 and b[0] == 0x02 and b[1] == 0x15:
            u = b[2:18].hex()
            uuid = "%s-%s-%s-%s-%s" % (u[0:8], u[8:12], u[12:16], u[16:20], u[20:32])
            ids.append("%s:%d:%d" % (uuid, int.from_bytes(b[18:20], "big"), int.from_bytes(b[20:22], "big")))
    return ids


def servico():
    from gi.repository import GLib
    m = ModoAula()
    if not m.conf["TUALALI_ESCOLA_URL"] and not m.conf["TUALALI_BEACONS"].strip():
        print("Modo Aula desativado: configure /etc/tualali/escola.conf", file=sys.stderr)
        return 0
    if m.estado["modo"] == "aula":        # religou no Modo Aula: continua travado
        m.trava.entrar()
        m.garantir_app()
    threading.Thread(target=m.atualizar_beacons, daemon=True).start()
    try:
        scanner = ScannerBLE(m.leitura)      # os sinais do D-Bus ja chegam no laco principal
        scanner.manter()
        GLib.timeout_add_seconds(30, scanner.manter)
    except Exception as e:  # noqa: BLE001
        print("Bluetooth nao iniciou:", e, file=sys.stderr)

    def tique():
        m.detector.tique(time.monotonic())
        m.simulacoes()
        m.garantir_app()
        return True
    GLib.timeout_add(1000, tique)
    GLib.timeout_add_seconds(600, lambda: (threading.Thread(target=m.atualizar_beacons, daemon=True).start(), True)[1])
    GLib.MainLoop().run()
    return 0


def main(argv):
    if len(argv) > 1 and argv[1] == "--simular":
        if len(argv) < 3:
            print("uso: tualali-modo-aula --simular IDENTIFICADOR_DO_BEACON")
            return 2
        os.makedirs(os.path.dirname(SIMULAR), exist_ok=True)
        with open(SIMULAR, "a") as f:
            f.write(argv[2] + "\n")
        print("Passagem simulada pelo beacon", argv[2])
        return 0
    if len(argv) > 1 and argv[1] == "--status":
        e, c = Estado(), ler_conf()
        print("Modo:", e["modo"])
        print("Codigo do computador:", e["codigo"] or "(ainda nao registrado)")
        print("Aluno:", e["aluno"] or "(nao ligado)")
        print("Plataforma:", c["TUALALI_ESCOLA_URL"] or "(nao configurada)")
        print("Beacons conhecidos:", ", ".join(sorted(ModoAula(c, e).conhecidos())) or "nenhum")
        return 0
    return servico()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
