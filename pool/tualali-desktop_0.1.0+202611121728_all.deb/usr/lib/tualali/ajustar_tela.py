#!/usr/bin/env python3
"""Ajustar Tela Tualali: corrige falhas de imagem (pontinhos/linha na borda) testando, com um clique,
os modos de "dithering" da tela. Telas de notebook antigas (ex.: MacBook Air 2010) mostram menos cores
do que a placa manda; o driver imita as cores que faltam com pontinhos que se mexem, e em algumas placas
NVIDIA isso aparece como uma linha de pontos descendo na borda.

  ajustar_tela.py            janela com as opcoes
  ajustar_tela.py --aplicar  aplica a opcao salva (roda sozinho a cada login)
"""
import os
import re
import subprocess
import sys

CONF = os.path.join(os.path.expanduser("~"), ".config", "tualali", "tela.conf")
OPCOES = [
    # (rotulo, dithering mode, dithering depth)
    ("Padrão do sistema", "auto", "auto"),
    ("Sem pontinhos (dithering desligado)", "off", "auto"),
    ("Pontinhos fixos (não se mexem)", "static 2x2", "6 bpc"),
    ("Cores completas (8 bits)", "off", "8 bpc"),
]


def saidas():
    """{saida: {propriedade: [valores aceitos]}} das telas conectadas com dithering (xrandr --prop)."""
    try:
        txt = subprocess.run(["xrandr", "--prop"], capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return {}
    r, atual, prop = {}, None, None
    for linha in txt.splitlines():
        m = re.match(r"^(\S+) connected", linha)
        if m:
            atual, prop = m.group(1), None
            r[atual] = {}
            continue
        if re.match(r"^\S", linha):
            atual = None
            continue
        if atual is None:
            continue
        m = re.match(r"^\s+(dithering (?:mode|depth)):", linha)
        if m:
            prop = m.group(1)
            r[atual][prop] = []
            continue
        m = re.match(r"^\s+supported:\s*(.*)$", linha)
        if m and prop:
            r[atual][prop] = [v.strip() for v in m.group(1).split(",") if v.strip()]
            prop = None
    return {s: p for s, p in r.items() if p}


def aplicar(indice):
    _r, modo, prof = OPCOES[indice]
    feitos = []
    for saida, props in saidas().items():
        cmd = ["xrandr", "--output", saida]
        if modo in props.get("dithering mode", []):
            cmd += ["--set", "dithering mode", modo]
        if prof in props.get("dithering depth", []):
            cmd += ["--set", "dithering depth", prof]
        if len(cmd) > 3 and subprocess.run(cmd, capture_output=True).returncode == 0:
            feitos.append(saida)
    return feitos


def salvo():
    try:
        with open(CONF) as f:
            return max(0, min(len(OPCOES) - 1, int(f.read().strip())))
    except (OSError, ValueError):
        return 0


def salvar(i):
    os.makedirs(os.path.dirname(CONF), exist_ok=True)
    with open(CONF, "w") as f:
        f.write(str(i))


def janela():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk
    j = Gtk.Window(title="Ajustar Tela")
    j.set_icon_name("video-display")
    j.set_border_width(18)
    j.set_default_size(460, -1)
    j.connect("destroy", Gtk.main_quit)
    caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    j.add(caixa)
    t = Gtk.Label(xalign=0)
    t.set_markup("<span size='large' weight='bold'>Ajustar Tela</span>")
    caixa.pack_start(t, False, False, 0)
    s = Gtk.Label(xalign=0, wrap=True, label="Se aparecem pontinhos ou uma linha descendo na borda da tela, clique "
                  "em cada opção e veja qual deixa a tela limpa. A escolha fica salva.")
    caixa.pack_start(s, False, False, 0)
    status = Gtk.Label(xalign=0, wrap=True)
    if os.environ.get("XDG_SESSION_TYPE") == "wayland":
        status.set_text("Esta sessão usa Wayland: o ajuste só funciona na sessão X11. "
                        "Reinicie o computador depois da última atualização do Tualali.")
    elif not saidas():
        status.set_text("Esta placa de vídeo não tem opções de pontinhos para ajustar.")
    grupo, atual = None, salvo()
    for i, (rotulo, _m, _p) in enumerate(OPCOES):
        b = Gtk.RadioButton.new_with_label_from_widget(grupo, rotulo)
        grupo = grupo or b
        b.set_active(i == atual)

        def mudou(botao, i=i):
            if botao.get_active():
                feitos = aplicar(i)
                salvar(i)
                status.set_text(("Aplicado na tela %s." % ", ".join(feitos)) if feitos else
                                "Não foi possível aplicar nesta tela.")
        b.connect("toggled", mudou)
        caixa.pack_start(b, False, False, 0)
    caixa.pack_start(status, False, False, 6)
    fechar = Gtk.Button(label="Fechar")
    fechar.connect("clicked", lambda *_: j.destroy())
    caixa.pack_end(fechar, False, False, 0)
    j.show_all()
    Gtk.main()


if __name__ == "__main__":
    if "--aplicar" in sys.argv:
        if salvo():
            aplicar(salvo())
    else:
        janela()
