// Mesas Tualali: areas de trabalho no estilo do Mac (Mission Control)
// - ao entrar no sistema abre direto na area de trabalho (sem a visao geral)
// - F3 (ou a tecla Mission Control do Mac) mostra todas as mesas; F3 de novo volta
// - na visao geral: botoes "+ Nova mesa" e "Remover esta mesa"; clique numa miniatura para trocar
// - na barra de cima: "Mesa N", com menu para trocar, criar e remover mesas
import Clutter from 'gi://Clutter';
import GObject from 'gi://GObject';
import Gio from 'gi://Gio';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

function preferencias() {
    return new Gio.Settings({schema_id: 'org.gnome.desktop.wm.preferences'});
}

function salvarQuantidade() {
    // mesas fixas: o numero fica salvo e as mesas continuam ao entrar de novo
    const p = preferencias();
    if (p.get_int('num-workspaces') !== global.workspace_manager.n_workspaces)
        p.set_int('num-workspaces', global.workspace_manager.n_workspaces);
}

export function novaMesa() {
    const wm = global.workspace_manager;
    const p = preferencias();
    // (a mudanca e aplicada logo depois: conta tambem os cliques que ainda estao a caminho)
    const n = Math.max(wm.n_workspaces, p.get_int('num-workspaces'));
    if (n >= 16)
        return;
    // mesmo caminho das Configuracoes do GNOME: aumenta o numero de mesas e vai para a nova
    const id = wm.connect('notify::n-workspaces', () => {
        if (wm.n_workspaces > n) {
            wm.disconnect(id);
            wm.get_workspace_by_index(n)?.activate(global.get_current_time());
        }
    });
    p.set_int('num-workspaces', n + 1);
}

export function removerMesa(indice) {
    const wm = global.workspace_manager;
    if (wm.n_workspaces <= 1)
        return;
    const i = indice ?? wm.get_active_workspace_index();
    const mesa = wm.get_workspace_by_index(i);
    const destino = wm.get_workspace_by_index(i > 0 ? i - 1 : 1);
    // as janelas da mesa removida vao para a mesa ao lado (nada e fechado)
    for (const w of mesa.list_windows()) {
        if (!w.is_on_all_workspaces())
            w.change_workspace(destino);
    }
    const t = global.get_current_time();
    if (wm.get_active_workspace() === mesa)
        destino.activate(t);
    wm.remove_workspace(mesa, t);
    salvarQuantidade();
}

const Indicador = GObject.registerClass(
class Indicador extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Mesas Tualali');
        this._rotulo = new St.Label({text: 'Mesa 1', y_align: Clutter.ActorAlign.CENTER});
        this.add_child(this._rotulo);
        global.workspace_manager.connectObject(
            'active-workspace-changed', () => this._atualizar(),
            'notify::n-workspaces', () => this._atualizar(), this);
        this._atualizar();
    }

    _atualizar() {
        this._rotulo.text = `Mesa ${global.workspace_manager.get_active_workspace_index() + 1}`;
        // o menu precisa estar montado antes do clique (o GNOME nao abre menu vazio)
        this._montar();
    }

    _montar() {
        this.menu.removeAll();
        const wm = global.workspace_manager;
        const ativa = wm.get_active_workspace_index();
        for (let i = 0; i < wm.n_workspaces; i++) {
            const item = new PopupMenu.PopupMenuItem(`Mesa ${i + 1}`);
            item.setOrnament(i === ativa ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
            item.connect('activate', () => wm.get_workspace_by_index(i)?.activate(global.get_current_time()));
            this.menu.addMenuItem(item);
        }
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Nova mesa', () => novaMesa());
        const remover = this.menu.addAction('Remover esta mesa', () => removerMesa());
        remover.setSensitive(wm.n_workspaces > 1);
        this.menu.addAction('Ver todas as mesas (F3)', () => Main.overview.show());
    }
});

export default class MesasTualali extends Extension {
    enable() {
        // 1. Abre direto na area de trabalho
        if (Main.layoutManager._startingUp) {
            this._tinhaVisaoGeral = Main.sessionMode.hasOverview;
            Main.sessionMode.hasOverview = false;
            Main.layoutManager.connectObject('startup-complete', () => {
                Main.sessionMode.hasOverview = this._tinhaVisaoGeral;
                Main.overview.hide();
            }, this);
        }

        // 2. Barra de cima
        this._indicador = new Indicador();
        Main.panel.addToStatusArea('tualali-mesas', this._indicador, 1, 'left');

        // 3. Botoes na visao geral (F3)
        this._botoes = new St.BoxLayout({style: 'spacing: 10px;', reactive: true, visible: false});
        const botao = (texto, acao) => {
            const b = new St.Button({
                label: texto, can_focus: true, reactive: true,
                style: 'padding: 8px 16px; border-radius: 18px; color: white; ' +
                       'background-color: rgba(46,196,182,0.85); font-weight: bold;',
            });
            b.connect('clicked', acao);
            this._botoes.add_child(b);
            return b;
        };
        botao('+  Nova mesa', () => novaMesa());
        this._remover = botao('Remover esta mesa', () => removerMesa());
        Main.layoutManager.addTopChrome(this._botoes);
        const posicionar = () => {
            const m = Main.layoutManager.primaryMonitor;
            if (!m)
                return;
            const [, largura] = this._botoes.get_preferred_width(-1);
            this._botoes.set_position(m.x + m.width - largura - 24, m.y + Main.panel.height + 16);
        };
        const mostrar = sim => {
            this._remover.reactive = global.workspace_manager.n_workspaces > 1;
            this._remover.opacity = this._remover.reactive ? 255 : 110;
            this._botoes.visible = sim;
            if (sim)
                posicionar();
        };
        Main.overview.connectObject(
            'showing', () => mostrar(true),
            'hiding', () => mostrar(false), this);
        global.workspace_manager.connectObject('notify::n-workspaces', () => {
            if (this._botoes.visible)
                mostrar(true);
        }, this);
        Main.layoutManager.connectObject('monitors-changed', () => posicionar(), this);
    }

    disable() {
        Main.layoutManager.disconnectObject(this);
        Main.overview.disconnectObject(this);
        global.workspace_manager.disconnectObject(this);
        if (this._tinhaVisaoGeral !== undefined)
            Main.sessionMode.hasOverview = this._tinhaVisaoGeral;
        this._indicador?.destroy();
        this._indicador = null;
        if (this._botoes) {
            Main.layoutManager.removeChrome(this._botoes);
            this._botoes.destroy();
            this._botoes = null;
        }
    }
}
