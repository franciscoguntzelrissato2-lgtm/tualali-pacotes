#!/usr/bin/env python3
"""Area do Estudante (Livro, Caderno, Atividades) do Tualali.

Normal:      area_estudante.py [livros|caderno|atividades]   -> janela comum
Modo Aula:   area_estudante.py --modo-aula                   -> tela cheia, sem fechar, so o site da escola
"""
import sys
import urllib.parse

sys.path.insert(0, "/usr/lib/tualali")
import modo_aula as ma  # noqa: E402
import gi  # noqa: E402

gi.require_version("Gtk", "3.0")
gi.require_version("WebKit2", "4.1")
from gi.repository import Gtk, Gdk, WebKit2, GLib  # noqa: E402

PAGINA_SEM_ESCOLA = """<html><body style="background:#0e1624;color:#e8eef7;font-family:sans-serif;display:grid;
place-items:center;height:95vh;text-align:center"><div><h1>Área do Estudante</h1><p>%s</p>
<p style="font-size:42px;letter-spacing:6px;color:#2ec4b6"><b>%s</b></p></div></body></html>"""


class Janela(Gtk.Window):
    def __init__(self, aula, aba):
        super().__init__(title="Área do Estudante")
        self.aula = aula
        self.set_icon_name("tualali-logo")
        self.set_default_size(1200, 800)
        conf, estado = ma.ler_conf(), ma.Estado()
        self.plat = ma.Plataforma(conf["TUALALI_ESCOLA_URL"], estado)
        self.origem = urllib.parse.urlsplit(conf["TUALALI_ESCOLA_URL"]).netloc

        ctx = WebKit2.WebContext.get_default()
        self.web = WebKit2.WebView.new_with_context(ctx)
        s = self.web.get_settings()
        s.set_enable_developer_extras(False)
        s.set_javascript_can_open_windows_automatically(False)
        self.web.connect("decide-policy", self.politica)
        self.web.connect("context-menu", lambda *a: True)          # sem menu do botao direito
        self.web.connect("load-failed", self.falhou)
        self.add(self.web)

        if aula:
            self.set_decorated(False)
            self.set_keep_above(True)
            self.fullscreen()
            self.connect("delete-event", lambda *a: True)            # nao fecha no Modo Aula
            self.connect("key-press-event", self.tecla)
        else:
            self.connect("destroy", Gtk.main_quit)
        self.carregar(aba)

    def carregar(self, aba):
        try:
            self.plat.registrar()
        except Exception:  # noqa: BLE001 - sem internet: mostra a pagina de aviso
            pass
        url = self.plat.url_estudante(aba)
        if url:
            self.web.load_uri(url)
        else:
            self.web.load_html(PAGINA_SEM_ESCOLA % ("Este computador ainda não está ligado a uma escola. "
                                                    "Peça ajuda à secretaria.", ""), None)

    def falhou(self, _w, _ev, uri, _erro):
        codigo = self.plat.estado["codigo"] or ""
        self.web.load_html(PAGINA_SEM_ESCOLA % ("Sem conexão com a escola. Tentando de novo em 20 segundos…", codigo),
                           None)
        GLib.timeout_add_seconds(20, lambda: (self.carregar("livros"), False)[1])
        return True

    def politica(self, _w, decisao, tipo):
        """So deixa navegar no site da escola (e no leitor de PDF do cdnjs)."""
        if tipo in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decisao.get_navigation_action().get_request().get_uri()
            host = urllib.parse.urlsplit(uri).netloc
            if tipo == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION or (host and host != self.origem
                                                                         and not uri.startswith("about:")):
                decisao.ignore()
                return True
        return False

    def tecla(self, _w, ev):
        # bloqueia atalhos de sair/fechar dentro da janela (Alt+F4, Esc da tela cheia, F11, Ctrl+W/Q/N/T)
        ctrl = ev.state & Gdk.ModifierType.CONTROL_MASK
        alt = ev.state & Gdk.ModifierType.MOD1_MASK
        nome = Gdk.keyval_name(ev.keyval) or ""
        if (alt and nome == "F4") or nome in ("F11", "Escape") or (ctrl and nome.lower() in ("w", "q", "n", "t", "o")):
            return True
        return False


def main(argv):
    aula = "--modo-aula" in argv
    aba = next((a for a in argv[1:] if a in ("livros", "caderno", "atividades")), "livros")
    j = Janela(aula, aba)
    j.show_all()
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
