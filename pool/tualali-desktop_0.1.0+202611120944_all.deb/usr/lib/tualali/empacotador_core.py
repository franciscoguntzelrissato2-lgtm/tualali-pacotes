#!/usr/bin/env python3
"""Empacotador Tualali (nucleo): transforma um programa do Windows (.exe) num pacote .deb.

O .deb gerado contem o programa original (sem conversao) e a configuracao do Wine do app:
- /opt/tualali-apps/<id>/programa/   arquivos do programa (o .exe ou a pasta instalada)
- /opt/tualali-apps/<id>/app.conf    nome, .exe principal, 32/64 bits
- /opt/tualali-apps/<id>/abrir       iniciador: cria a "garrafa" Wine do app (Windows 10,
                                      pasta propria em ~/.local/share/tualali-apps/<id>) e abre
- /usr/share/applications/<pacote>.desktop e o icone extraido do .exe
O Wine em si e compartilhado (pacote do Debian), instalado uma vez para todos os apps.

Uso em linha de comando (tambem usado nos testes):
  empacotador_core.py --nome "Meu App" --exe programa.exe [--pasta pasta_do_programa] --saida DIR
"""
import argparse
import datetime
import os
import re
import shutil
import struct
import subprocess
import tempfile
import unicodedata

BASE = "/opt/tualali-apps"

INICIADOR = r'''#!/bin/bash
# Iniciador gerado pelo Empacotador Tualali
D="$(dirname "$(readlink -f "$0")")"
. "$D/app.conf"
export WINEPREFIX="$HOME/.local/share/tualali-apps/$ID"
export WINEDEBUG=-all
LOG="$HOME/.local/share/tualali-apps/$ID.log"
mkdir -p "$HOME/.local/share/tualali-apps"
aviso() { zenity --error --title="$NOME" --text="$1" 2>/dev/null || notify-send "$NOME" "$1"; }

if ! command -v wine >/dev/null 2>&1; then
  if zenity --question --title="$NOME" --text="Para abrir $NOME é preciso instalar o Wine (programas do Windows).\nInstalar agora? (precisa de internet)" 2>/dev/null; then
    pkexec sh -c 'dpkg --add-architecture i386 && apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y wine wine64 wine32:i386' \
      || { aviso "Não foi possível instalar o Wine."; exit 1; }
  else exit 1; fi
fi
if [ "$BITS" = 32 ] && ! dpkg-query -W -f='${Status}' wine32:i386 2>/dev/null | grep -q 'ok installed'; then
  if zenity --question --title="$NOME" --text="$NOME é um programa de 32 bits e precisa do Wine 32 bits.\nInstalar agora? (precisa de internet)" 2>/dev/null; then
    pkexec sh -c 'dpkg --add-architecture i386 && apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y wine32:i386' \
      || { aviso "Não foi possível instalar o Wine 32 bits."; exit 1; }
  else exit 1; fi
fi

# Primeira vez (ou versao nova do pacote): prepara a garrafa e copia o programa para ela,
# porque muitos programas do Windows gravam arquivos na propria pasta.
DEST="$WINEPREFIX/drive_c/Tualali/$ID"
if [ ! -f "$WINEPREFIX/.tualali-versao" ] || [ "$(cat "$WINEPREFIX/.tualali-versao")" != "$VERSAO" ]; then
  ( echo "# Preparando $NOME pela primeira vez…"
    if [ ! -d "$WINEPREFIX/drive_c" ]; then wineboot -i >>"$LOG" 2>&1; wine reg add 'HKCU\Software\Wine' /v Version /d win10 /f >>"$LOG" 2>&1; fi
    mkdir -p "$DEST" && cp -a "$D/programa/." "$DEST/"
    echo "$VERSAO" > "$WINEPREFIX/.tualali-versao"
  ) | zenity --progress --pulsate --auto-close --no-cancel --title="$NOME" 2>/dev/null \
    || { [ -d "$WINEPREFIX/drive_c" ] || wineboot -i >>"$LOG" 2>&1; mkdir -p "$DEST"; cp -a "$D/programa/." "$DEST/"; echo "$VERSAO" > "$WINEPREFIX/.tualali-versao"; }
fi
cd "$DEST/$(dirname "$EXE")" || { aviso "Os arquivos de $NOME não foram encontrados."; exit 1; }
exec wine "$(basename "$EXE")" "$@" 2>>"$LOG"
'''


def slug(texto):
    t = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode().lower()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    return (t or "app")[:40]


def bits_do_exe(caminho):
    """32 ou 64 conforme o cabecalho PE do .exe (padrao 32)."""
    try:
        with open(caminho, "rb") as f:
            if f.read(2) != b"MZ":
                return None
            f.seek(0x3C)
            pe = struct.unpack("<I", f.read(4))[0]
            f.seek(pe)
            if f.read(4) != b"PE\0\0":
                return None
            maquina = struct.unpack("<H", f.read(2))[0]
    except (OSError, struct.error):
        return None
    return 64 if maquina in (0x8664, 0xAA64) else 32


def extrair_icone(exe, destino_png):
    """Extrai o maior icone do .exe (icoutils). Devolve True se conseguiu."""
    if not shutil.which("wrestool") or not shutil.which("icotool"):
        return False
    with tempfile.TemporaryDirectory() as tmp:
        try:
            subprocess.run(["wrestool", "-x", "-t", "14", "-o", tmp, exe],
                           capture_output=True, timeout=60)
            for ico in os.listdir(tmp):
                if ico.endswith(".ico"):
                    subprocess.run(["icotool", "-x", "-o", tmp, os.path.join(tmp, ico)],
                                   capture_output=True, timeout=60)
        except (OSError, subprocess.SubprocessError):
            return False
        pngs = [os.path.join(tmp, p) for p in os.listdir(tmp) if p.endswith(".png")]
        if not pngs:
            return False

        def tamanho(p):
            m = re.search(r"_(\d+)x(\d+)x(\d+)\.png$", p)
            return (int(m.group(1)), int(m.group(3))) if m else (0, os.path.getsize(p))
        shutil.copy(max(pngs, key=tamanho), destino_png)
    return True


def gerar_deb(nome, exe, pasta=None, saida=".", versao=None, log=print):
    """Gera o .deb. exe: caminho do .exe principal. pasta: pasta inteira do programa
    (instaladores); se None, empacota so o .exe. Devolve o caminho do .deb."""
    exe = os.path.abspath(exe)
    nome = " ".join(str(nome).split())[:60] or "Programa"
    if pasta:
        pasta = os.path.abspath(pasta)
        rel = os.path.relpath(exe, pasta)
        if rel.startswith(".."):
            raise ValueError("O .exe principal precisa estar dentro da pasta do programa.")
    else:
        rel = os.path.basename(exe)
    bits = bits_do_exe(exe)
    if bits is None:
        raise ValueError("O arquivo não é um programa do Windows (.exe) válido.")
    ident = slug(nome)
    pacote = "tualali-app-" + ident
    versao = versao or "1.0+" + datetime.datetime.now().strftime("%Y%m%d%H%M")

    with tempfile.TemporaryDirectory() as st:
        app = os.path.join(st, BASE.lstrip("/"), ident)
        prog = os.path.join(app, "programa")
        log("Copiando os arquivos do programa…")
        if pasta:
            shutil.copytree(pasta, prog, symlinks=True)
        else:
            os.makedirs(prog)
            shutil.copy2(exe, os.path.join(prog, rel))
        with open(os.path.join(app, "app.conf"), "w") as f:
            f.write("NOME=%s\nID=%s\nEXE=%s\nBITS=%d\nVERSAO=%s\n" % (
                _q(nome), _q(ident), _q(rel), bits, _q(versao)))
        with open(os.path.join(app, "abrir"), "w") as f:
            f.write(INICIADOR)

        log("Extraindo o ícone…")
        icones = os.path.join(st, "usr/share/icons/hicolor/256x256/apps")
        os.makedirs(icones)
        icone = pacote if extrair_icone(exe, os.path.join(icones, pacote + ".png")) else "wine"
        if icone == "wine":
            os.rmdir(icones)

        apps = os.path.join(st, "usr/share/applications")
        os.makedirs(apps)
        with open(os.path.join(apps, pacote + ".desktop"), "w") as f:
            f.write("[Desktop Entry]\nType=Application\nName=%s\nComment=Programa do Windows (Empacotador Tualali)\n"
                    "Exec=%s/%s/abrir %%F\nIcon=%s\nTerminal=false\nCategories=Wine;\n"
                    "StartupWMClass=%s\n" % (nome, BASE, ident, icone, os.path.basename(rel).lower()))

        deb = os.path.join(st, "DEBIAN")
        os.makedirs(deb)
        kb = sum(os.path.getsize(os.path.join(r, n)) for r, _, fs in os.walk(st) for n in fs
                 if not os.path.islink(os.path.join(r, n))) // 1024 + 1
        with open(os.path.join(deb, "control"), "w") as f:
            f.write("Package: %s\nVersion: %s\nArchitecture: all\n"
                    "Maintainer: Empacotador Tualali <empacotador@tualali.local>\n"
                    "Installed-Size: %d\nDepends: wine, zenity\nRecommends: wine64\nSection: otherosfs\n"
                    "Priority: optional\nDescription: %s (programa do Windows)\n"
                    " Gerado pelo Empacotador Tualali: contem o programa original do Windows\n"
                    " e a configuracao do Wine para abri-lo como um app normal.\n"
                    % (pacote, versao, kb, nome))
        # permissoes: pastas 755, arquivos 644, iniciador e .exe executaveis
        for r, ds, fs in os.walk(st):
            for d in ds:
                os.chmod(os.path.join(r, d), 0o755)
            for n in fs:
                p = os.path.join(r, n)
                if not os.path.islink(p):
                    os.chmod(p, 0o755 if n == "abrir" or n.lower().endswith(".exe") else 0o644)

        os.makedirs(saida, exist_ok=True)
        arquivo = os.path.join(os.path.abspath(saida), "%s_%s_all.deb" % (pacote, versao))
        log("Gerando o pacote .deb…")
        r = subprocess.run(["dpkg-deb", "--root-owner-group", "-Zxz", "--build", st, arquivo],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("dpkg-deb falhou: " + r.stderr.strip())
    return arquivo


def _q(v):
    """Valor seguro para o app.conf (lido pelo bash com '.')."""
    return "'" + str(v).replace("'", "'\\''") + "'"


def main():
    a = argparse.ArgumentParser(description="Empacotador Tualali: .exe -> .deb")
    a.add_argument("--nome", required=True)
    a.add_argument("--exe", required=True)
    a.add_argument("--pasta")
    a.add_argument("--saida", default=".")
    o = a.parse_args()
    print(gerar_deb(o.nome, o.exe, o.pasta, o.saida))


if __name__ == "__main__":
    main()
