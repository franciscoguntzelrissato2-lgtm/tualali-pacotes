#!/usr/bin/env python3
"""Empacotador Tualali: dois cliques num .exe -> app .deb (programa original + Wine configurado)."""
import os
import re
import shutil
import subprocess
import sys
import threading

sys.path.insert(0, "/usr/lib/tualali")
import tualali_common as tc  # noqa: E402
from tualali_common import Gtk, GLib  # noqa: E402
import empacotador_core as core  # noqa: E402

SAIDA = os.path.join(os.path.expanduser("~"), "Pacotes Tualali")
CACHE = os.path.join(os.path.expanduser("~"), ".cache", "tualali-empacotador")
IGNORAR = re.compile(r"unins|uninstall|desinst|setup|install|update|updater|crash|report|helper|vcredist|dxsetup",
                     re.I)
INSTALAR_WINE = ("dpkg --add-architecture i386 && apt-get update && "
                 "DEBIAN_FRONTEND=noninteractive apt-get install -y wine wine64 wine32:i386")


def nome_sugerido(caminho):
    n = os.path.splitext(os.path.basename(caminho))[0]
    n = re.sub(r"(?i)v?\d+(\.\d+)+", " ", n)            # versoes: 3.0.21, v1.2
    n = re.sub(r"[_\.\-]+", " ", n)
    n = re.sub(r"(?i)\b(setup|install(er)?|x64|x86|amd64|win(32|64)?|portable|full|\d+)\b", " ", n)
    palavras = n.split()
    n = " ".join(p if any(c.isupper() for c in p) else p.capitalize() for p in palavras)
    return n or "Meu Programa"


class Empacotador(Gtk.Window):
    def __init__(self, arquivo=None):
        super().__init__(title="Empacotador Tualali")
        self.set_default_size(560, 420)
        self.set_border_width(18)
        self.set_icon_name("tualali-logo")
        self.caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(self.caixa)

        t = Gtk.Label(xalign=0)
        t.set_markup("<span size='x-large' weight='bold'>Empacotador Tualali</span>")
        self.caixa.pack_start(t, False, False, 0)
        s = Gtk.Label(xalign=0, label="Transforma um programa do Windows (.exe) num app do Tualali (.deb). "
                                       "O programa não é convertido: ele vai dentro do app junto com a "
                                       "configuração do Wine.")
        s.set_line_wrap(True)
        self.caixa.pack_start(s, False, False, 0)

        grade = Gtk.Grid(column_spacing=10, row_spacing=8)
        self.caixa.pack_start(grade, False, False, 6)
        grade.attach(Gtk.Label(label="Arquivo:", xalign=1), 0, 0, 1, 1)
        self.escolher = Gtk.FileChooserButton(title="Escolha o .exe", action=Gtk.FileChooserAction.OPEN)
        filtro = Gtk.FileFilter()
        filtro.set_name("Programas do Windows (.exe, .msi)")
        for p in ("*.exe", "*.EXE", "*.msi", "*.MSI"):
            filtro.add_pattern(p)
        self.escolher.add_filter(filtro)
        self.escolher.set_hexpand(True)
        self.escolher.connect("file-set", self.arquivo_escolhido)
        grade.attach(self.escolher, 1, 0, 1, 1)
        grade.attach(Gtk.Label(label="Nome do app:", xalign=1), 0, 1, 1, 1)
        self.nome = Gtk.Entry()
        grade.attach(self.nome, 1, 1, 1, 1)

        self.r_prog = Gtk.RadioButton.new_with_label(None, "Este .exe é o próprio programa (abre direto)")
        self.r_inst = Gtk.RadioButton.new_with_label_from_widget(
            self.r_prog, "Este .exe é um instalador (setup) — vou instalar e depois escolher o programa")
        self.caixa.pack_start(self.r_prog, False, False, 0)
        self.caixa.pack_start(self.r_inst, False, False, 0)

        self.status = Gtk.Label(xalign=0)
        self.status.set_line_wrap(True)
        self.caixa.pack_start(self.status, False, False, 6)
        self.giro = Gtk.Spinner()
        self.caixa.pack_start(self.giro, False, False, 0)

        botoes = Gtk.Box(spacing=8)
        self.caixa.pack_end(botoes, False, False, 0)
        self.criar = Gtk.Button(label="Criar app (.deb)")
        self.criar.get_style_context().add_class("suggested-action")
        self.criar.connect("clicked", self.comecar)
        fechar = Gtk.Button(label="Fechar")
        fechar.connect("clicked", lambda *_: self.destroy())
        botoes.pack_end(self.criar, False, False, 0)
        botoes.pack_end(fechar, False, False, 0)

        if arquivo:
            self.escolher.set_filename(arquivo)
            self.arquivo_escolhido()

    # ---------- interface ----------
    def arquivo_escolhido(self, *_):
        f = self.escolher.get_filename() or ""
        self.nome.set_text(nome_sugerido(f))
        base = os.path.basename(f).lower()
        if base.endswith(".msi") or re.search(r"setup|install", base):
            self.r_inst.set_active(True)
        else:
            self.r_prog.set_active(True)
        self.r_prog.set_sensitive(not base.endswith(".msi"))

    def msg(self, texto, girando=None):
        def f():
            self.status.set_text(texto)
            if girando is True:
                self.giro.start()
            elif girando is False:
                self.giro.stop()
            return False
        GLib.idle_add(f)

    def ocupado(self, sim):
        GLib.idle_add(lambda: (self.criar.set_sensitive(not sim), False)[1])

    def comecar(self, _b):
        f = self.escolher.get_filename()
        if not f or not os.path.isfile(f):
            self.msg("Escolha primeiro um arquivo .exe.")
            return
        if self.r_inst.get_active():
            self.instalar_primeiro(f)
        else:
            self.ocupado(True)
            threading.Thread(target=self.gerar, args=(f, None), daemon=True).start()

    # ---------- programa direto ----------
    def gerar(self, exe, pasta):
        self.msg("Criando o app…", True)
        try:
            deb = core.gerar_deb(self.nome.get_text(), exe, pasta, SAIDA, log=lambda t: self.msg(t, True))
        except Exception as e:  # noqa: BLE001 - mostrar qualquer erro ao usuario
            self.msg("Erro: %s" % e, False)
            self.ocupado(False)
            return
        self.msg("Pronto! App criado em:\n%s" % deb, False)
        self.ocupado(False)
        GLib.idle_add(self.pronto, deb)

    def pronto(self, deb):
        d = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.NONE, text="App criado!")
        d.format_secondary_text("O arquivo %s está na pasta \"Pacotes Tualali\".\n"
                                "Instale para ele aparecer no menu de aplicativos." % os.path.basename(deb))
        d.add_button("Abrir pasta", 1)
        d.add_button("Instalar agora", 2)
        r = d.run()
        d.destroy()
        if r == 1:
            tc.spawn(["xdg-open", SAIDA])
        elif r == 2:
            tc.spawn(["/usr/bin/python3", "/usr/lib/tualali/instalar-deb.py", deb])
        return False

    # ---------- instalador (setup.exe / .msi) ----------
    def instalar_primeiro(self, inst):
        if not shutil.which("wine"):
            d = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.QUESTION,
                                  buttons=Gtk.ButtonsType.YES_NO,
                                  text="Para rodar o instalador é preciso o Wine")
            d.format_secondary_text("Instalar o Wine agora? Precisa de internet e da senha de administrador.")
            r = d.run()
            d.destroy()
            if r != Gtk.ResponseType.YES:
                return
            p = tc.run_privileged_in_terminal("Instalando o Wine", INSTALAR_WINE)

            def esperar():
                if p and p.poll() is None:
                    return True
                if shutil.which("wine"):
                    self.instalar_primeiro(inst)
                else:
                    self.msg("O Wine não foi instalado. Tente de novo.", False)
                return False
            GLib.timeout_add(1000, esperar)
            return
        self.ocupado(True)
        threading.Thread(target=self.rodar_instalador, args=(inst,), daemon=True).start()

    def rodar_instalador(self, inst):
        ident = core.slug(self.nome.get_text())
        prefixo = os.path.join(CACHE, ident)
        shutil.rmtree(prefixo, ignore_errors=True)
        os.makedirs(prefixo)
        env = dict(os.environ, WINEPREFIX=prefixo, WINEDEBUG="-all")
        self.msg("Preparando o Wine… (na primeira vez pode levar alguns minutos)", True)
        subprocess.run(["wineboot", "-i"], env=env, capture_output=True)
        subprocess.run(["wine", "reg", "add", r"HKCU\Software\Wine", "/v", "Version", "/d", "win10", "/f"],
                       env=env, capture_output=True)
        self.msg("Siga as etapas do instalador que abriu. Quando ele terminar, volto aqui.", True)
        cmd = ["wine", "msiexec", "/i", inst] if inst.lower().endswith(".msi") else ["wine", inst]
        subprocess.run(cmd, env=env, capture_output=True, cwd=os.path.dirname(inst))
        subprocess.run(["wineserver", "-w"], env=env, capture_output=True)
        achados = self.procurar_exes(prefixo)
        if not achados:
            self.msg("Não encontrei nenhum programa instalado. O instalador terminou mesmo?", False)
            self.ocupado(False)
            return
        GLib.idle_add(self.escolher_principal, achados)

    @staticmethod
    def procurar_exes(prefixo):
        c = os.path.join(prefixo, "drive_c")
        bases = [os.path.join(c, "Program Files"), os.path.join(c, "Program Files (x86)")]
        bases += [os.path.join(u, "AppData", "Local", "Programs")
                  for u in [os.path.join(c, "users", x) for x in os.listdir(os.path.join(c, "users"))]
                  ] if os.path.isdir(os.path.join(c, "users")) else []
        achados = []
        for base in bases:
            if not os.path.isdir(base):
                continue
            for raiz, _, arquivos in os.walk(base):
                topo = os.path.relpath(raiz, base).split(os.sep)[0]
                if topo in ("Common Files", "Internet Explorer", "Windows Media Player", "Windows NT",
                            "Windows Photo Viewer", "Microsoft.NET", "."):
                    continue
                for a in arquivos:
                    if a.lower().endswith(".exe") and not IGNORAR.search(a):
                        p = os.path.join(raiz, a)
                        achados.append((os.path.getsize(p), p, os.path.join(base, topo)))
        achados.sort(reverse=True)
        return achados

    def escolher_principal(self, achados):
        self.msg("Instalação concluída. Escolha qual é o programa principal.", False)
        d = Gtk.Dialog(title="Qual é o programa principal?", transient_for=self)
        d.add_button("Cancelar", Gtk.ResponseType.CANCEL)
        d.add_button("Criar app", Gtk.ResponseType.OK)
        lista = Gtk.ComboBoxText()
        for _, p, pasta in achados[:30]:
            lista.append_text(os.path.relpath(p, os.path.dirname(pasta)))
        lista.set_active(0)
        d.get_content_area().set_spacing(8)
        d.get_content_area().add(Gtk.Label(label="Programas encontrados (o maior aparece primeiro):"))
        d.get_content_area().add(lista)
        d.show_all()
        r = d.run()
        i = lista.get_active()
        d.destroy()
        if r != Gtk.ResponseType.OK or i < 0:
            self.ocupado(False)
            return False
        _, exe, pasta = achados[i]
        threading.Thread(target=self.gerar, args=(exe, pasta), daemon=True).start()
        return False


def main():
    tc.load_css()
    arquivo = sys.argv[1] if len(sys.argv) > 1 else None
    if arquivo and arquivo.startswith("file://"):
        from urllib.parse import unquote, urlparse
        arquivo = unquote(urlparse(arquivo).path)
    j = Empacotador(arquivo)
    j.connect("destroy", Gtk.main_quit)
    j.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
