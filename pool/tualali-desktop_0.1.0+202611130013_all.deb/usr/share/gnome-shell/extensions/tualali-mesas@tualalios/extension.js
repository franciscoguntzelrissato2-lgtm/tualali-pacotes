// Mesas Tualali: areas de trabalho no estilo do Mac (Mission Control)
// - ao entrar no sistema abre direto na area de trabalho (sem a visao geral)
// - F3 (ou a tecla Mission Control do Mac) mostra todas as mesas; F3 de novo volta
// - na visao geral: botoes "+ Nova mesa" e "Remover esta mesa"; clique numa miniatura para trocar
// - na barra de cima: "Mesa N", com menu para trocar, criar e remover mesas
// - cada mesa tem o proprio papel de parede (menu "Fundo desta mesa" ou Configuracoes > Aparencia)
// - mudou o fundo: a tela de login e o menu de inicializacao (GRUB) ficam com o mesmo fundo
import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Gio from 'gi://Gio';
import St from 'gi://St';

const DIR_FOTOS = '/usr/share/backgrounds/tualali/';
const FOTOS = [
    ['natureza-brasileira.xml', 'Todas (troca a cada 30 min)'],
    ['lencois-maranhenses.jpg', 'Lençóis Maranhenses'], ['fernando-de-noronha.jpg', 'Fernando de Noronha'],
    ['lago-do-cunia.jpg', 'Aurora no Lago do Cuniã'], ['aparados-da-serra.jpg', 'Aparados da Serra'],
    ['pedra-azul.jpg', 'Pedra Azul e a Via Láctea'], ['arara-azul-pantanal.jpg', 'Arara-azul no Pantanal'],
    ['serra-geral.jpg', 'Serra Geral'], ['mangue-de-guaratiba.jpg', 'Manhã em Guaratiba'],
    ['onca-do-pantanal.jpg', 'Onça-pintada no Pantanal'], ['parque-do-tainhas.jpg', 'Parque do Tainhas'],
    ['serra-da-capivara.jpg', 'Serra da Capivara'], ['ilha-do-cardoso.jpg', 'Ilha do Cardoso'],
];

let fundos = null;

// Papel de parede de cada mesa. O GNOME tem um fundo so; ao trocar de mesa, a extensao troca o fundo.
class FundosDasMesas {
    constructor() {
        this._bg = new Gio.Settings({schema_id: 'org.gnome.desktop.background'});
        this._bloqueio = new Gio.Settings({schema_id: 'org.gnome.desktop.screensaver'});
        this._arquivo = GLib.build_filenamev([GLib.get_user_config_dir(), 'tualali', 'mesas-fundos.json']);
        this._mapa = this._ler();
        this._esperado = null;
        global.workspace_manager.connectObject('active-workspace-changed', () => this._mostrarMesa(), this);
        this._bg.connectObject('changed::picture-uri', () => this._mudouFora(), this);
        this._mostrarMesa();
    }

    destroy() {
        global.workspace_manager.disconnectObject(this);
        this._bg.disconnectObject(this);
    }

    _ler() {
        try {
            const [ok, dados] = GLib.file_get_contents(this._arquivo);
            if (ok)
                return JSON.parse(new TextDecoder().decode(dados)) || {};
        } catch (e) {}
        return {};
    }

    _salvar() {
        try {
            GLib.mkdir_with_parents(GLib.path_get_dirname(this._arquivo), 0o700);
            GLib.file_set_contents(this._arquivo, JSON.stringify(this._mapa));
        } catch (e) {
            console.warn(`Mesas Tualali: nao salvou os fundos: ${e}`);
        }
    }

    _ativa() {
        return global.workspace_manager.get_active_workspace_index();
    }

    fundoDaMesa(i) {
        return this._mapa[String(i)] ?? null;
    }

    _usar(uri) {
        if (this._bg.get_string('picture-uri') === uri && this._bg.get_string('picture-uri-dark') === uri)
            return;
        this._esperado = uri;
        this._bg.set_string('picture-uri', uri);
        this._bg.set_string('picture-uri-dark', uri);
        this._bloqueio.set_string('picture-uri', uri);
    }

    _mostrarMesa() {
        const i = this._ativa();
        const uri = this.fundoDaMesa(i);
        if (uri) {
            this._usar(uri);
        } else {
            // mesa sem fundo escolhido: fica com o que esta na tela
            this._mapa[String(i)] = this._bg.get_string('picture-uri');
            this._salvar();
        }
    }

    // A pessoa mudou o fundo nas Configuracoes > Aparencia: vale para a mesa atual
    _mudouFora() {
        const uri = this._bg.get_string('picture-uri');
        if (uri === this._esperado)
            return;
        this._mapa[String(this._ativa())] = uri;
        this._salvar();
        if (this._bg.get_string('picture-uri-dark') !== uri) {
            this._esperado = uri;
            this._bg.set_string('picture-uri-dark', uri);
        }
        this._bloqueio.set_string('picture-uri', uri);
        this._sincronizarSistema(uri);
    }

    escolher(i, uri) {
        this._mapa[String(i)] = uri;
        this._salvar();
        if (i === this._ativa())
            this._usar(uri);
        this._sincronizarSistema(uri);
    }

    mesaRemovida(k) {
        const novo = {};
        for (const [chave, uri] of Object.entries(this._mapa)) {
            const i = parseInt(chave);
            if (i < k)
                novo[String(i)] = uri;
            else if (i > k)
                novo[String(i - 1)] = uri;
        }
        this._mapa = novo;
        this._salvar();
    }

    // Tela de login e GRUB com o mesmo fundo (helper do Tualali, liberado para a sessao ativa sem senha)
    _sincronizarSistema(uri) {
        if (!uri || !uri.startsWith('file://'))
            return;
        const caminho = Gio.File.new_for_uri(uri).get_path();
        if (!caminho || !GLib.file_test('/usr/lib/tualali/fundo-sistema', GLib.FileTest.EXISTS))
            return;
        try {
            Gio.Subprocess.new(['pkexec', '/usr/lib/tualali/fundo-sistema', caminho], Gio.SubprocessFlags.NONE);
        } catch (e) {
            console.warn(`Mesas Tualali: fundo do login nao mudou: ${e}`);
        }
    }
}

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

function preferencias() {
    return new Gio.Settings({schema_id: 'org.gnome.desktop.wm.preferences'});
}

function salvarQuantidade() {
    // mesas fixas: o numero fica salvo e as mesas continuam ao entrar de novo
    const p = preferencias();
    if (p.get_int('num-workspaces') !== global.workspace_manager.n_workspaces)
        p.set_int('num-workspaces', global.workspace_manager.n_workspaces);
}

export function novaMesa() {
    const wm = global.workspace_manager;
    const p = preferencias();
    // (a mudanca e aplicada logo depois: conta tambem os cliques que ainda estao a caminho)
    const n = Math.max(wm.n_workspaces, p.get_int('num-workspaces'));
    if (n >= 16)
        return;
    // mesmo caminho das Configuracoes do GNOME: aumenta o numero de mesas e vai para a nova
    const id = wm.connect('notify::n-workspaces', () => {
        if (wm.n_workspaces > n) {
            wm.disconnect(id);
            wm.get_workspace_by_index(n)?.activate(global.get_current_time());
        }
    });
    p.set_int('num-workspaces', n + 1);
}

export function removerMesa(indice) {
    const wm = global.workspace_manager;
    if (wm.n_workspaces <= 1)
        return;
    const i = indice ?? wm.get_active_workspace_index();
    const mesa = wm.get_workspace_by_index(i);
    const destino = wm.get_workspace_by_index(i > 0 ? i - 1 : 1);
    // as janelas da mesa removida vao para a mesa ao lado (nada e fechado)
    for (const w of mesa.list_windows()) {
        if (!w.is_on_all_workspaces())
            w.change_workspace(destino);
    }
    const t = global.get_current_time();
    if (wm.get_active_workspace() === mesa)
        destino.activate(t);
    wm.remove_workspace(mesa, t);
    fundos?.mesaRemovida(i);
    salvarQuantidade();
}

const Indicador = GObject.registerClass(
class Indicador extends PanelMenu.Button {
    _init() {
        super._init(0.0, 'Mesas Tualali');
        this._rotulo = new St.Label({text: 'Mesa 1', y_align: Clutter.ActorAlign.CENTER});
        this.add_child(this._rotulo);
        global.workspace_manager.connectObject(
            'active-workspace-changed', () => this._atualizar(),
            'notify::n-workspaces', () => this._atualizar(), this);
        this._atualizar();
    }

    _atualizar() {
        this._rotulo.text = `Mesa ${global.workspace_manager.get_active_workspace_index() + 1}`;
        // o menu precisa estar montado antes do clique (o GNOME nao abre menu vazio)
        this._montar();
    }

    _montar() {
        this.menu.removeAll();
        const wm = global.workspace_manager;
        const ativa = wm.get_active_workspace_index();
        for (let i = 0; i < wm.n_workspaces; i++) {
            const item = new PopupMenu.PopupMenuItem(`Mesa ${i + 1}`);
            item.setOrnament(i === ativa ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
            item.connect('activate', () => wm.get_workspace_by_index(i)?.activate(global.get_current_time()));
            this.menu.addMenuItem(item);
        }
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        // Fundo desta mesa (cada mesa pode ter uma imagem diferente)
        const sub = new PopupMenu.PopupSubMenuMenuItem(`Fundo da Mesa ${ativa + 1}`);
        const atual = fundos?.fundoDaMesa(ativa);
        for (const [arquivo, nome] of FOTOS) {
            const uri = `file://${DIR_FOTOS}${arquivo}`;
            const item = new PopupMenu.PopupMenuItem(nome);
            item.setOrnament(uri === atual ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
            item.connect('activate', () => {
                fundos?.escolher(ativa, uri);
                GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                    this._montar();
                    return GLib.SOURCE_REMOVE;
                });
            });
            sub.menu.addMenuItem(item);
        }
        sub.menu.addAction('Outra imagem… (Configurações)', () => {
            try {
                Gio.Subprocess.new(['gnome-control-center', 'background'], Gio.SubprocessFlags.NONE);
            } catch (e) {}
        });
        this.menu.addMenuItem(sub);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Nova mesa', () => novaMesa());
        const remover = this.menu.addAction('Remover esta mesa', () => removerMesa());
        remover.setSensitive(wm.n_workspaces > 1);
        this.menu.addAction('Ver todas as mesas (F3)', () => Main.overview.show());
    }
});

export default class MesasTualali extends Extension {
    enable() {
        // 1. Abre direto na area de trabalho
        if (Main.layoutManager._startingUp) {
            this._tinhaVisaoGeral = Main.sessionMode.hasOverview;
            Main.sessionMode.hasOverview = false;
            Main.layoutManager.connectObject('startup-complete', () => {
                Main.sessionMode.hasOverview = this._tinhaVisaoGeral;
                Main.overview.hide();
            }, this);
        }

        // 2. Fundo de cada mesa
        fundos = new FundosDasMesas();
        this._fundos = fundos;

        // 3. Barra (menu "Mesa N")
        this._indicador = new Indicador();
        Main.panel.addToStatusArea('tualali-mesas', this._indicador, 1, 'left');

        // 3. Botoes na visao geral (F3)
        this._botoes = new St.BoxLayout({style: 'spacing: 10px;', reactive: true, visible: false});
        const botao = (texto, acao) => {
            const b = new St.Button({
                label: texto, can_focus: true, reactive: true,
                style: 'padding: 8px 16px; border-radius: 18px; color: white; ' +
                       'background-color: rgba(46,196,182,0.85); font-weight: bold;',
            });
            b.connect('clicked', acao);
            this._botoes.add_child(b);
            return b;
        };
        botao('+  Nova mesa', () => novaMesa());
        this._remover = botao('Remover esta mesa', () => removerMesa());
        Main.layoutManager.addTopChrome(this._botoes);
        const posicionar = () => {
            const m = Main.layoutManager.primaryMonitor;
            if (!m)
                return;
            const [, largura] = this._botoes.get_preferred_width(-1);
            // com a barra unica embaixo nao ha barra no topo: os botoes ficam na borda de cima
            const [, yBarra] = Main.panel.get_transformed_position();
            const topo = Main.panel.visible && yBarra <= m.y + 1 ? Main.panel.height : 0;
            this._botoes.set_position(m.x + m.width - largura - 24, m.y + topo + 10);
        };
        const mostrar = sim => {
            this._remover.reactive = global.workspace_manager.n_workspaces > 1;
            this._remover.opacity = this._remover.reactive ? 255 : 110;
            this._botoes.visible = sim;
            if (sim)
                posicionar();
        };
        Main.overview.connectObject(
            'showing', () => mostrar(true),
            'hiding', () => mostrar(false), this);
        global.workspace_manager.connectObject('notify::n-workspaces', () => {
            if (this._botoes.visible)
                mostrar(true);
        }, this);
        Main.layoutManager.connectObject('monitors-changed', () => posicionar(), this);
    }

    disable() {
        Main.layoutManager.disconnectObject(this);
        Main.overview.disconnectObject(this);
        global.workspace_manager.disconnectObject(this);
        if (this._tinhaVisaoGeral !== undefined)
            Main.sessionMode.hasOverview = this._tinhaVisaoGeral;
        this._indicador?.destroy();
        this._indicador = null;
        fundos?.destroy();
        fundos = null;
        if (this._botoes) {
            Main.layoutManager.removeChrome(this._botoes);
            this._botoes.destroy();
            this._botoes = null;
        }
    }
}
