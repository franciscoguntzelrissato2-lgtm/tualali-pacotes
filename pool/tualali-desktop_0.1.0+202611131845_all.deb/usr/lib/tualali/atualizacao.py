#!/usr/bin/env python3
"""Atualizacao de Software do Tualali (estilo Apple). Abre tambem por Configuracoes > Sistema >
Atualizacoes de Software. Mostra se ha atualizacao, instala com barra de progresso e reinicia no fim."""
import datetime
import os
import re
import shutil
import subprocess
import sys
import threading

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gdk  # noqa: E402

HELPER = "/usr/lib/tualali/atualizar-sistema"
SEGUNDOS_PARA_REINICIAR = 15

CSS = b"""
.janela-atualizacao { background-color: @theme_bg_color; }
.titulo-grande { font-size: 20px; font-weight: 700; }
.subtitulo { font-size: 13px; opacity: 0.7; }
.botao-pilula { border-radius: 999px; padding: 8px 28px; font-weight: 700; font-size: 14px;
  background-image: none; background-color: #0a84ff; color: #ffffff; border: none; box-shadow: none; }
.botao-pilula:hover { background-color: #3a9bff; }
.botao-pilula:disabled { background-color: alpha(#0a84ff, 0.4); color: alpha(#ffffff, 0.8); }
.link { color: #0a84ff; background: none; border: none; box-shadow: none; padding: 2px 6px; }
.cartao { background-color: alpha(@theme_fg_color, 0.05); border-radius: 14px; padding: 14px 18px; }
progressbar trough { min-height: 8px; border-radius: 999px; }
progressbar progress { min-height: 8px; border-radius: 999px; background-color: #0a84ff; border: none; }
"""


def versao_tualali():
    try:
        return open("/usr/share/tualali/VERSION").read().strip()
    except OSError:
        return "?"


def pendentes():
    """Lista de (pacote, versao nova) do sistema que a atualizacao vai instalar (simulacao, sem administrador)."""
    r = subprocess.run(["apt-get", "-s", "-o", "Debug::NoLocking=1", "full-upgrade"],
                       capture_output=True, text=True)
    itens = []
    for linha in r.stdout.splitlines():
        m = re.match(r"^Inst (\S+) (?:\[[^\]]*\] )?\(([^ )]+)", linha)
        if m:
            itens.append((m.group(1), m.group(2)))
    return itens


def apps_pendentes():
    """Apps da Loja (Flathub) com atualizacao: [(nome, versao, 'system'|'user')]."""
    if not shutil.which("flatpak"):
        return []
    itens = []
    for onde in ("--system", "--user"):
        try:
            r = subprocess.run(["flatpak", "remote-ls", onde, "--updates", "--app",
                                "--columns=name,application,version"], capture_output=True, text=True, timeout=90)
        except (OSError, subprocess.SubprocessError):
            continue
        for linha in r.stdout.splitlines():
            partes = linha.split("\t")
            if len(partes) >= 2 and partes[1] and "." in partes[1]:
                itens.append((partes[0] or partes[1], partes[2] if len(partes) > 2 else "", onde[2:]))
    return itens


class Atualizacao(Gtk.Window):
    def __init__(self):
        super().__init__(title="Atualização de Software")
        self.set_default_size(560, 440)
        self.set_icon_name("tualali-atualizacao")
        self.get_style_context().add_class("janela-atualizacao")
        barra = Gtk.HeaderBar(title="Atualização de Software", show_close_button=True)
        self.set_titlebar(barra)

        caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=28)
        self.add(caixa)
        topo = Gtk.Box(spacing=18)
        caixa.pack_start(topo, False, False, 0)
        icone = Gtk.Image.new_from_icon_name("tualali-atualizacao", Gtk.IconSize.DIALOG)
        icone.set_pixel_size(96)
        topo.pack_start(icone, False, False, 0)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, valign=Gtk.Align.CENTER)
        topo.pack_start(textos, True, True, 0)
        self.titulo = Gtk.Label(xalign=0, wrap=True)
        self.titulo.get_style_context().add_class("titulo-grande")
        self.sub = Gtk.Label(xalign=0, wrap=True)
        self.sub.get_style_context().add_class("subtitulo")
        textos.pack_start(self.titulo, False, False, 0)
        textos.pack_start(self.sub, False, False, 0)

        self.cartao = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.cartao.get_style_context().add_class("cartao")
        caixa.pack_start(self.cartao, False, False, 8)
        self.info = Gtk.Label(xalign=0, wrap=True)
        self.cartao.pack_start(self.info, False, False, 0)
        self.progresso = Gtk.ProgressBar()
        self.cartao.pack_start(self.progresso, False, False, 0)
        self.passo = Gtk.Label(xalign=0, wrap=True)
        self.passo.get_style_context().add_class("subtitulo")
        self.cartao.pack_start(self.passo, False, False, 0)

        self.detalhes = Gtk.Expander(label="Mais informações…")
        self.lista = Gtk.Label(xalign=0, yalign=0, selectable=True, wrap=True)
        rolagem = Gtk.ScrolledWindow(min_content_height=110)
        rolagem.add(self.lista)
        self.detalhes.add(rolagem)
        caixa.pack_start(self.detalhes, True, True, 0)

        botoes = Gtk.Box(spacing=10, halign=Gtk.Align.END)
        caixa.pack_end(botoes, False, False, 0)
        self.secundario = Gtk.Button(label="Verificar de novo")
        self.secundario.get_style_context().add_class("link")
        self.secundario.connect("clicked", lambda *_: self.verificar(baixar_lista=True))
        self.principal = Gtk.Button(label="Atualizar Agora")
        self.principal.get_style_context().add_class("botao-pilula")
        self.principal.connect("clicked", self.clicou_principal)
        botoes.pack_start(self.secundario, False, False, 0)
        botoes.pack_start(self.principal, False, False, 0)

        self.estado = None
        self.contagem = 0
        self.connect("destroy", Gtk.main_quit)
        self.verificar()

    # ---------- estados ----------
    def mostrar(self, estado, titulo, sub="", info="", progresso=None, passo="", botao=None, sensivel=True):
        self.estado = estado
        self.titulo.set_text(titulo)
        self.sub.set_text(sub)
        self.info.set_text(info)
        self.info.set_visible(bool(info))
        self.progresso.set_visible(progresso is not None)
        if progresso is not None:
            self.progresso.set_fraction(max(0.0, min(1.0, progresso)))
        self.passo.set_text(passo)
        self.passo.set_visible(bool(passo))
        self.principal.set_visible(botao is not None)
        if botao:
            self.principal.set_label(botao)
        self.principal.set_sensitive(sensivel)
        self.secundario.set_visible(estado in ("atualizado", "disponivel", "erro"))
        self.cartao.set_visible(bool(info) or progresso is not None or bool(passo))
        return False

    def verificar(self, baixar_lista=False):
        self.mostrar("verificando", "Verificando atualizações…", "Tualali OS %s" % versao_tualali(),
                     progresso=0.0, passo="Isso leva só alguns segundos.")
        self.progresso.pulse()
        self._pulsando = GLib.timeout_add(120, lambda: (self.progresso.pulse(), self.estado == "verificando")[1])
        threading.Thread(target=self._verificar, args=(baixar_lista,), daemon=True).start()

    def _verificar(self, baixar_lista):
        if baixar_lista:
            subprocess.run(["pkexec", HELPER, "--verificar"], capture_output=True)
        itens = pendentes()
        # os apps sao atualizados pela Loja Tualali (aba Atualizacoes); aqui fica so o sistema
        GLib.idle_add(self._resultado, itens, [])

    def _resultado(self, itens, apps):
        agora = datetime.datetime.now().strftime("%H:%M")
        self.itens, self.apps = itens, apps
        if not itens and not apps:
            self.lista.set_text("Nenhuma atualização pendente.")
            return self.mostrar("atualizado", "O Tualali OS está atualizado",
                                "Tualali OS %s · verificado hoje às %s" % (versao_tualali(), agora),
                                info="As atualizações dos apps ficam na Loja Tualali, na aba Atualizações.")
        tualali = [v for p, v in itens if p == "tualali-desktop"]
        nome = "Tualali OS %s" % versao_tualali() + (" — nova versão %s" % tualali[0].split("+")[-1] if tualali else "")
        linhas = []
        if apps:
            linhas.append("Apps:")
            linhas += ["  %s  %s" % (n, v) for n, v, _o in apps]
        if itens:
            linhas.append("Sistema:")
            linhas += ["  %s  →  %s" % (p, v) for p, v in itens]
        self.lista.set_text("\n".join(linhas))
        partes = []
        if itens:
            partes.append("%d %s do sistema" % (len(itens), "item" if len(itens) == 1 else "itens"))
        if apps:
            partes.append("%d %s" % (len(apps), "app" if len(apps) == 1 else "apps"))
        fim = (" O computador reinicia sozinho quando terminar." if itens else " Não precisa reiniciar.")
        return self.mostrar("disponivel", "Atualização disponível",
                            nome if itens else "Atualização dos apps instalados",
                            info="%s para atualizar.%s" % (" e ".join(partes), fim),
                            botao="Atualizar Agora")

    def clicou_principal(self, _b):
        if self.estado == "disponivel":
            self.instalar()
        elif self.estado == "concluido":
            self.reiniciar()
        elif self.estado == "erro":
            self.verificar()

    def instalar(self):
        self.mostrar("instalando", "Atualizando o Tualali OS…", "Não desligue o computador.",
                     progresso=0.01, passo="Preparando…", botao="Atualizar Agora", sensivel=False)
        threading.Thread(target=self._instalar, daemon=True).start()

    def _instalar(self):
        sistema = bool(getattr(self, "itens", None))
        apps = getattr(self, "apps", None) or []
        precisa_root = sistema or any(o == "system" for _n, _v, o in apps)
        codigo = "0"
        if precisa_root:
            codigo = self._rodar_helper("--instalar" if sistema else "--apps")
            if codigo is None:
                return
        if codigo == "0" and any(o == "user" for _n, _v, o in apps):
            GLib.idle_add(self._progresso, 0.95, "Atualizando os seus apps…")
            subprocess.run(["flatpak", "update", "--user", "-y", "--noninteractive"], capture_output=True)
        if codigo == "0":
            GLib.idle_add(self.concluido, sistema)
        else:
            GLib.idle_add(self.mostrar, "erro", "A atualização não terminou",
                          "Verifique a internet e tente de novo. Detalhes: /var/log/tualali-atualizacao.log",
                          botao="Tentar de novo")

    def _rodar_helper(self, modo):
        """Roda o helper com administrador; devolve o codigo final, ou None se a senha nao foi confirmada."""
        try:
            p = subprocess.Popen(["pkexec", HELPER, modo], stdout=subprocess.PIPE, text=True, bufsize=1)
        except OSError as e:
            GLib.idle_add(self.mostrar, "erro", "Não foi possível atualizar", str(e), botao="Tentar de novo")
            return None
        codigo = None
        for linha in p.stdout:
            partes = linha.strip().split(" ", 2)
            if partes[0] == "PROGRESSO" and len(partes) >= 2:
                pct = float(partes[1]) / 100.0
                texto = partes[2] if len(partes) > 2 else ""
                GLib.idle_add(self._progresso, pct, texto)
            elif partes[0] == "FIM" and len(partes) >= 2:
                codigo = partes[1]
        p.wait()
        if p.returncode in (126, 127) and codigo is None:
            GLib.idle_add(self.mostrar, "disponivel", "Atualização disponível", "A senha não foi confirmada.",
                          botao="Atualizar Agora")
            return None
        return codigo or str(p.returncode)

    def _progresso(self, pct, texto):
        self.progresso.set_fraction(max(self.progresso.get_fraction(), min(1.0, pct)))
        self.passo.set_text(texto)
        return False

    def concluido(self, reiniciar=True):
        if not reiniciar:
            # so apps foram atualizados: nao precisa reiniciar
            self.mostrar("atualizado", "Apps atualizados", "Os apps instalados estão na versão mais nova.",
                         progresso=1.0, passo="Pronto.")
            return False
        self.contagem = SEGUNDOS_PARA_REINICIAR
        self.mostrar("concluido", "Atualização concluída", "O computador vai reiniciar para terminar.",
                     progresso=1.0, passo="Reiniciando em %d segundos…" % self.contagem, botao="Reiniciar Agora")
        GLib.timeout_add_seconds(1, self._contar)
        return False

    def _contar(self):
        if self.estado != "concluido":
            return False
        self.contagem -= 1
        if self.contagem <= 0:
            self.reiniciar()
            return False
        self.passo.set_text("Reiniciando em %d segundos…" % self.contagem)
        return True

    def reiniciar(self):
        self.mostrar("reiniciando", "Reiniciando…", "", progresso=1.0)
        subprocess.Popen(["systemctl", "reboot"])


def main():
    prov = Gtk.CssProvider()
    prov.load_from_data(CSS)
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov,
                                             Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    GLib.set_prgname("tualali-atualizacao")
    # segue o modo escuro/claro do sistema
    try:
        from gi.repository import Gio
        escuro = Gio.Settings.new("org.gnome.desktop.interface").get_string("color-scheme") == "prefer-dark"
        Gtk.Settings.get_default().set_property("gtk-application-prefer-dark-theme", escuro)
    except Exception:  # noqa: BLE001
        pass
    j = Atualizacao()
    j.show_all()
    j.mostrar(j.estado, j.titulo.get_text(), j.sub.get_text(), j.info.get_text(),
              j.progresso.get_fraction() if j.estado == "verificando" else None, j.passo.get_text(),
              j.principal.get_label() if j.principal.get_visible() else None)
    Gtk.main()


if __name__ == "__main__":
    sys.exit(main())
