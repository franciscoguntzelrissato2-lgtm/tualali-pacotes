#!/usr/bin/env python3
"""Apps Livro e Caderno do Tualali (conteudo da plataforma da escola).

  area_estudante.py livro     -> app Livro (livros da sala)
  area_estudante.py caderno   -> app Caderno (paginas do caderno + atividades dos professores)

Cada app so navega na propria parte da Area do Estudante. No Modo Aula sao (com as Configuracoes)
os unicos apps que abrem; quem bloqueia o resto e o modo_aula.py.
"""
import os
import re
import sys
import urllib.parse

sys.path.insert(0, "/usr/lib/tualali")
import modo_aula as ma  # noqa: E402

APPS = {
    # app: (titulo, icone, aba inicial, abas permitidas, caminhos permitidos, css)
    "livro": ("Livro", "accessories-dictionary", "livros", ("", "livros"), ("/estudante/livros/",),
              ".abas{display:none!important}"),
    "caderno": ("Caderno", "accessories-text-editor", "caderno", ("caderno", "atividades"),
                ("/estudante/caderno", "/estudante/atividades/"), '.abas a[href="?aba=livros"]{display:none!important}'),
}
ANTIGOS = {"livros": "livro", "atividades": "caderno"}   # nomes usados nas versoes anteriores

PAGINA_SEM_ESCOLA = """<html><body style="background:#0e1624;color:#e8eef7;font-family:sans-serif;display:grid;
place-items:center;height:95vh;text-align:center"><div><h1>%s</h1><p>%s</p>
<p style="font-size:42px;letter-spacing:6px;color:#2ec4b6"><b>%s</b></p></div></body></html>"""


def permitido(app, uri, origem):
    """O app pode abrir este endereco? (so a propria parte da Area do Estudante)"""
    if not uri or uri.startswith("about:"):
        return True
    p = urllib.parse.urlsplit(uri)
    if p.netloc != origem:
        return False
    _t, _i, _a, abas, caminhos, _css = APPS[app]
    if p.path == "/estudante/entrar":
        return True
    if p.path in ("/estudante/", "/estudante"):
        return urllib.parse.parse_qs(p.query).get("aba", [""])[0] in abas
    return any(p.path == c or p.path.startswith(c) for c in caminhos)


PASTA_CADERNO = os.path.join(os.path.expanduser("~"), ".local", "share", "tualali", "caderno")


def nome_arquivo(titulo):
    t = re.sub(r"[^\w\- ]+", "", titulo, flags=re.UNICODE).strip()[:60]
    return (t or "Pagina") + ".txt"


class CadernoLocal:
    """Caderno deste computador: funciona sem internet e sem escola. Cada pagina e um .txt
    em ~/.local/share/tualali/caderno e salva sozinha enquanto a pessoa escreve."""

    def __init__(self, Gtk, GLib, ao_tentar):
        self.Gtk, self.GLib = Gtk, GLib
        os.makedirs(PASTA_CADERNO, exist_ok=True)
        self.atual, self.tempo = None, None
        self.raiz = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        topo = Gtk.Box(spacing=8, margin=8)
        self.aviso = Gtk.Label(xalign=0, wrap=True)
        topo.pack_start(self.aviso, True, True, 0)
        tentar = Gtk.Button(label="Tentar a escola de novo")
        tentar.connect("clicked", lambda *_: ao_tentar())
        topo.pack_end(tentar, False, False, 0)
        self.raiz.pack_start(topo, False, False, 0)
        corpo = Gtk.Paned()
        self.raiz.pack_start(corpo, True, True, 0)
        lado = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=8)
        lado.set_size_request(240, -1)
        self.lista = Gtk.ListBox()
        self.lista.connect("row-selected", self._escolheu)
        rol = Gtk.ScrolledWindow()
        rol.add(self.lista)
        lado.pack_start(rol, True, True, 0)
        self.novo = Gtk.Entry(placeholder_text="Nova matéria (ex.: Matemática)")
        self.novo.connect("activate", self._criar)
        lado.pack_start(self.novo, False, False, 0)
        b = Gtk.Button(label="+ Nova página")
        b.connect("clicked", self._criar)
        lado.pack_start(b, False, False, 0)
        corpo.pack1(lado, False, False)
        direita = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin=8)
        self.salvo = Gtk.Label(xalign=1)
        direita.pack_start(self.salvo, False, False, 0)
        self.texto = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, left_margin=12, right_margin=12,
                                  top_margin=12, bottom_margin=12)
        self.texto.get_buffer().connect("changed", self._mudou)
        rol2 = Gtk.ScrolledWindow()
        rol2.add(self.texto)
        direita.pack_start(rol2, True, True, 0)
        corpo.pack2(direita, True, False)
        self._listar()

    def _paginas(self):
        return sorted(f for f in os.listdir(PASTA_CADERNO) if f.endswith(".txt"))

    def _listar(self, escolher=None):
        for r in self.lista.get_children():
            self.lista.remove(r)
        paginas = self._paginas()
        if not paginas:
            with open(os.path.join(PASTA_CADERNO, "Minhas anotações.txt"), "w") as f:
                f.write("")
            paginas = self._paginas()
        for p in paginas:
            linha = self.Gtk.ListBoxRow()
            linha.arquivo = p
            linha.add(self.Gtk.Label(label=p[:-4], xalign=0, margin=6))
            self.lista.add(linha)
        self.lista.show_all()
        alvo = escolher or paginas[0]
        for r in self.lista.get_children():
            if r.arquivo == alvo:
                self.lista.select_row(r)

    def _escolheu(self, _l, linha):
        if not linha:
            return
        self._salvar()
        self.atual = linha.arquivo
        try:
            with open(os.path.join(PASTA_CADERNO, self.atual)) as f:
                conteudo = f.read()
        except OSError:
            conteudo = ""
        self._carregando = True
        self.texto.get_buffer().set_text(conteudo)
        self._carregando = False
        self.salvo.set_text("salvo neste computador")
        self.texto.grab_focus()

    def _criar(self, *_):
        nome = nome_arquivo(self.novo.get_text() or "Nova página")
        caminho = os.path.join(PASTA_CADERNO, nome)
        if not os.path.exists(caminho):
            open(caminho, "w").close()
        self.novo.set_text("")
        self._listar(escolher=nome)

    def _mudou(self, *_):
        if getattr(self, "_carregando", False):
            return
        self.salvo.set_text("salvando…")
        if self.tempo:
            self.GLib.source_remove(self.tempo)
        self.tempo = self.GLib.timeout_add(700, self._salvar)

    def _salvar(self):
        self.tempo = None
        if self.atual:
            b = self.texto.get_buffer()
            with open(os.path.join(PASTA_CADERNO, self.atual), "w") as f:
                f.write(b.get_text(b.get_start_iter(), b.get_end_iter(), True))
            self.salvo.set_text("salvo neste computador")
        return False


def escolher_app(argv):
    for a in argv[1:]:
        a = ANTIGOS.get(a, a)
        if a in APPS:
            return a
    return "livro"


def main(argv):
    app = escolher_app(argv)
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("WebKit2", "4.1")
    from gi.repository import Gtk, WebKit2, GLib

    GLib.set_prgname("tualali-" + app)          # liga a janela ao icone certo na dock
    titulo, icone, aba, _abas, _cam, css = APPS[app]
    GLib.set_application_name(titulo)

    conf, estado = ma.ler_conf(), ma.Estado()
    plat = ma.Plataforma(conf["TUALALI_ESCOLA_URL"], estado)
    origem = urllib.parse.urlsplit(conf["TUALALI_ESCOLA_URL"]).netloc

    janela = Gtk.Window(title=titulo)
    janela.set_icon_name(icone)
    janela.set_default_size(1200, 800)
    janela.connect("destroy", Gtk.main_quit)

    ucm = WebKit2.UserContentManager()
    ucm.add_style_sheet(WebKit2.UserStyleSheet(css, WebKit2.UserContentInjectedFrames.ALL_FRAMES,
                                               WebKit2.UserStyleLevel.USER, None, None))
    web = WebKit2.WebView.new_with_user_content_manager(ucm)
    s = web.get_settings()
    s.set_enable_developer_extras(False)
    s.set_javascript_can_open_windows_automatically(False)
    web.connect("context-menu", lambda *a: True)                 # sem menu do botao direito

    def politica(_w, decisao, tipo):
        if tipo == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
            decisao.ignore()
            return True
        if tipo == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
            uri = decisao.get_navigation_action().get_request().get_uri()
            if not permitido(app, uri, origem):
                decisao.ignore()
                return True
        return False

    # Caderno: se a escola nao responder (ou o computador ainda nao foi ligado a um aluno),
    # abre o caderno deste computador, que funciona sem internet
    pilha = Gtk.Stack()
    pilha.add_named(web, "web")
    local = None
    if app == "caderno":
        local = CadernoLocal(Gtk, GLib, lambda: carregar())
        pilha.add_named(local.raiz, "local")

    def usar_local(motivo):
        if not local:
            return False
        local.aviso.set_markup("<b>Caderno deste computador</b> — %s" % GLib.markup_escape_text(motivo))
        pilha.set_visible_child_name("local")
        return True

    def carregou(_w, evento):
        if evento != WebKit2.LoadEvent.FINISHED or not local:
            return
        r = web.get_main_resource()
        resp = r.get_response() if r else None
        if resp and resp.get_status_code() == 403:
            usar_local("este computador ainda não foi ligado a um aluno pela escola (código %s)."
                       % (estado["codigo"] or "?"))
        elif resp and resp.get_status_code() < 400 and web.get_uri() and web.get_uri().startswith("http"):
            pilha.set_visible_child_name("web")

    def carregar():
        motivo = ""
        try:
            plat.registrar()
        except Exception as e:  # noqa: BLE001 - sem internet: mostra o aviso com o motivo
            motivo = str(e)
        url = plat.url_estudante(aba)
        if not url and usar_local("sem conexão com a escola. Suas anotações ficam salvas aqui."):
            return False
        if url:
            web.load_uri(url)
        elif not conf["TUALALI_ESCOLA_URL"]:
            web.load_html(PAGINA_SEM_ESCOLA % (titulo, "Este computador ainda não tem o endereço da escola. "
                                               "Peça ajuda à secretaria.", ""), None)
        else:
            web.load_html(PAGINA_SEM_ESCOLA % (titulo, "Não foi possível falar com a escola (%s). "
                                               "Tentando de novo em 20 segundos… Detalhe: %s"
                                               % (origem, motivo[:160] or "sem resposta"), ""), None)
            GLib.timeout_add_seconds(20, carregar)
        return False

    def falhou(_w, _ev, _uri, erro):
        # endereco bloqueado pela politica ou carregamento cancelado: nao e falta de internet
        if (erro.matches(WebKit2.PolicyError.quark(), WebKit2.PolicyError.FRAME_LOAD_INTERRUPTED_BY_POLICY_CHANGE)
                or erro.matches(WebKit2.NetworkError.quark(), WebKit2.NetworkError.CANCELLED)):
            return False
        if usar_local("sem conexão com a escola. Suas anotações ficam salvas aqui."):
            return True
        web.load_html(PAGINA_SEM_ESCOLA % (titulo, "Sem conexão com a escola. Tentando de novo em 20 segundos… "
                                           "Detalhe: %s" % erro.message[:160],
                                           estado["codigo"] or ""), None)
        GLib.timeout_add_seconds(20, carregar)
        return True

    web.connect("decide-policy", politica)
    web.connect("load-failed", falhou)
    web.connect("load-changed", carregou)
    janela.add(pilha)
    janela.show_all()          # antes de carregar: a pilha so troca para paginas ja visiveis
    carregar()
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
