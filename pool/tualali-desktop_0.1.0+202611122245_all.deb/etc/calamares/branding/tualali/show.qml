import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation {
    id: presentation
    Timer {
        interval: 6000; running: presentation.activatedInCalamares; repeat: true
        onTriggered: presentation.goToNextSlide()
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0e1624" }
        Image { id: logo; source: "logo.png"; width: 128; height: 128; anchors.centerIn: parent; anchors.verticalCenterOffset: -50 }
        Text { anchors.top: logo.bottom; anchors.topMargin: 20; anchors.horizontalCenter: parent.horizontalCenter
               color: "#eef3f8"; font.pixelSize: 22; text: "Instalando o Tualali OS…" }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0e1624" }
        Text { anchors.centerIn: parent; width: parent.width * 0.8; wrapMode: Text.WordWrap
               horizontalAlignment: Text.AlignHCenter; color: "#eef3f8"; font.pixelSize: 18
               text: "Use a Loja Tualali para instalar LibreOffice, VLC, GIMP e programas do Windows (Wine)." }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0e1624" }
        Text { anchors.centerIn: parent; width: parent.width * 0.8; wrapMode: Text.WordWrap
               horizontalAlignment: Text.AlignHCenter; color: "#eef3f8"; font.pixelSize: 18
               text: "Atalhos: Super+Espaço abre o menu, Super+E os arquivos, Super+T o terminal, Super+L bloqueia." }
    }
}
