#!/usr/bin/env python3
"""Apps Livro e Caderno do Tualali (conteudo da plataforma da escola).

  area_estudante.py livro     -> app Livro (livros da sala)
  area_estudante.py caderno   -> app Caderno (paginas do caderno + atividades dos professores)

Cada app so navega na propria parte da Area do Estudante. No Modo Aula sao (com as Configuracoes)
os unicos apps que abrem; quem bloqueia o resto e o modo_aula.py.
"""
import sys
import urllib.parse

sys.path.insert(0, "/usr/lib/tualali")
import modo_aula as ma  # noqa: E402

APPS = {
    # app: (titulo, icone, aba inicial, abas permitidas, caminhos permitidos, css)
    "livro": ("Livro", "accessories-dictionary", "livros", ("", "livros"), ("/estudante/livros/",),
              ".abas{display:none!important}"),
    "caderno": ("Caderno", "accessories-text-editor", "caderno", ("caderno", "atividades"),
                ("/estudante/caderno", "/estudante/atividades/"), '.abas a[href="?aba=livros"]{display:none!important}'),
}
ANTIGOS = {"livros": "livro", "atividades": "caderno"}   # nomes usados nas versoes anteriores

PAGINA_SEM_ESCOLA = """<html><body style="background:#0e1624;color:#e8eef7;font-family:sans-serif;display:grid;
place-items:center;height:95vh;text-align:center"><div><h1>%s</h1><p>%s</p>
<p style="font-size:42px;letter-spacing:6px;color:#2ec4b6"><b>%s</b></p></div></body></html>"""


def permitido(app, uri, origem):
    """O app pode abrir este endereco? (so a propria parte da Area do Estudante)"""
    if not uri or uri.startswith("about:"):
        return True
    p = urllib.parse.urlsplit(uri)
    if p.netloc != origem:
        return False
    _t, _i, _a, abas, caminhos, _css = APPS[app]
    if p.path == "/estudante/entrar":
        return True
    if p.path in ("/estudante/", "/estudante"):
        return urllib.parse.parse_qs(p.query).get("aba", [""])[0] in abas
    return any(p.path == c or p.path.startswith(c) for c in caminhos)


def escolher_app(argv):
    for a in argv[1:]:
        a = ANTIGOS.get(a, a)
        if a in APPS:
            return a
    return "livro"


def main(argv):
    app = escolher_app(argv)
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("WebKit2", "4.1")
    from gi.repository import Gtk, WebKit2, GLib

    GLib.set_prgname("tualali-" + app)          # liga a janela ao icone certo na dock
    titulo, icone, aba, _abas, _cam, css = APPS[app]
    GLib.set_application_name(titulo)

    conf, estado = ma.ler_conf(), ma.Estado()
    plat = ma.Plataforma(conf["TUALALI_ESCOLA_URL"], estado)
    origem = urllib.parse.urlsplit(conf["TUALALI_ESCOLA_URL"]).netloc

    janela = Gtk.Window(title=titulo)
    janela.set_icon_name(icone)
    janela.set_default_size(1200, 800)
    janela.connect("destroy", Gtk.main_quit)

    ucm = WebKit2.UserContentManager()
    ucm.add_style_sheet(WebKit2.UserStyleSheet(css, WebKit2.UserContentInjectedFrames.ALL_FRAMES,
                                               WebKit2.UserStyleLevel.USER, None, None))
    web = WebKit2.WebView.new_with_user_content_manager(ucm)
    s = web.get_settings()
    s.set_enable_developer_extras(False)
    s.set_javascript_can_open_windows_automatically(False)
    web.connect("context-menu", lambda *a: True)                 # sem menu do botao direito

    def politica(_w, decisao, tipo):
        if tipo == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
            decisao.ignore()
            return True
        if tipo == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
            uri = decisao.get_navigation_action().get_request().get_uri()
            if not permitido(app, uri, origem):
                decisao.ignore()
                return True
        return False

    def carregar():
        try:
            plat.registrar()
        except Exception:  # noqa: BLE001 - sem internet: mostra o aviso
            pass
        url = plat.url_estudante(aba)
        if url:
            web.load_uri(url)
        else:
            web.load_html(PAGINA_SEM_ESCOLA % (titulo, "Este computador ainda não está ligado a uma escola. "
                                               "Peça ajuda à secretaria.", ""), None)
        return False

    def falhou(_w, _ev, _uri, erro):
        # endereco bloqueado pela politica ou carregamento cancelado: nao e falta de internet
        if (erro.matches(WebKit2.PolicyError.quark(), WebKit2.PolicyError.FRAME_LOAD_INTERRUPTED_BY_POLICY_CHANGE)
                or erro.matches(WebKit2.NetworkError.quark(), WebKit2.NetworkError.CANCELLED)):
            return False
        web.load_html(PAGINA_SEM_ESCOLA % (titulo, "Sem conexão com a escola. Tentando de novo em 20 segundos…",
                                           estado["codigo"] or ""), None)
        GLib.timeout_add_seconds(20, carregar)
        return True

    web.connect("decide-policy", politica)
    web.connect("load-failed", falhou)
    janela.add(web)
    carregar()
    janela.show_all()
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
