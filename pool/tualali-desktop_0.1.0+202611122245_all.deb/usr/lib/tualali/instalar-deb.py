#!/usr/bin/env python3
"""Instalador de Pacotes Tualali: abre arquivos .deb com dois cliques e instala com o apt
(que tambem baixa as dependencias que faltarem)."""
import os
import shlex
import subprocess
import sys

sys.path.insert(0, "/usr/lib/tualali")
import tualali_common as tc  # noqa: E402
from tualali_common import Gtk, GLib  # noqa: E402


def campo(deb, nome):
    out = tc.run(["dpkg-deb", "-f", deb, nome], timeout=10)
    return (out or "").strip()


def instalado(pacote):
    out = tc.run(["dpkg-query", "-W", "-f=${Status}|${Version}", pacote])
    if out and out.startswith("install ok installed|"):
        return out.split("|", 1)[1]
    return None


def erro(msg):
    d = Gtk.MessageDialog(message_type=Gtk.MessageType.ERROR, buttons=Gtk.ButtonsType.CLOSE,
                          text="Não foi possível abrir o pacote")
    d.format_secondary_text(msg)
    d.run()
    d.destroy()


class Janela(Gtk.Window):
    def __init__(self, deb):
        super().__init__(title="Instalador de Pacotes Tualali")
        self.deb = deb
        self.pacote = campo(deb, "Package")
        self.versao = campo(deb, "Version")
        self.set_default_size(520, 320)
        self.set_border_width(18)
        self.set_icon_name("tualali-logo")
        caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(caixa)

        titulo = Gtk.Label(xalign=0)
        titulo.set_markup("<span size='x-large' weight='bold'>%s</span>" % GLib.markup_escape_text(self.pacote))
        caixa.pack_start(titulo, False, False, 0)
        desc = campo(deb, "Description").split("\n")
        resumo = Gtk.Label(label=desc[0], xalign=0)
        resumo.set_line_wrap(True)
        caixa.pack_start(resumo, False, False, 0)
        detalhe = Gtk.Label(label="\n".join(l.strip() for l in desc[1:] if l.strip() != "."), xalign=0)
        detalhe.set_line_wrap(True)
        detalhe.get_style_context().add_class("dim-label")
        caixa.pack_start(detalhe, False, False, 0)

        atual = instalado(self.pacote)
        info = "Versão: %s" % self.versao
        if atual:
            info += "   (instalada no computador: %s)" % atual
        info += "\nArquivo: %s" % os.path.basename(deb)
        caixa.pack_start(Gtk.Label(label=info, xalign=0), False, False, 6)

        aviso = Gtk.Label(xalign=0)
        aviso.set_line_wrap(True)
        aviso.set_markup("<small>Instale apenas pacotes de fontes em que você confia. "
                         "Será pedida a senha de administrador.</small>")
        caixa.pack_start(aviso, False, False, 0)

        botoes = Gtk.Box(spacing=8)
        caixa.pack_end(botoes, False, False, 0)
        texto = "Reinstalar" if atual == self.versao else ("Atualizar" if atual else "Instalar")
        self.botao = Gtk.Button(label=texto)
        self.botao.get_style_context().add_class("suggested-action")
        self.botao.connect("clicked", self.instalar)
        fechar = Gtk.Button(label="Cancelar")
        fechar.connect("clicked", lambda *_: self.destroy())
        botoes.pack_end(self.botao, False, False, 0)
        botoes.pack_end(fechar, False, False, 0)

    def instalar(self, _b):
        self.botao.set_sensitive(False)
        self.botao.set_label("Instalando…")
        cmd = ("DEBIAN_FRONTEND=noninteractive apt-get install -y --reinstall %s"
               % shlex.quote(os.path.abspath(self.deb)))
        p = tc.run_privileged_in_terminal("Instalando %s" % self.pacote, cmd)
        if p is None:
            erro("Não foi possível abrir o terminal de instalação.")
            self.destroy()
            return

        def fim():
            if p.poll() is None:
                return True
            if instalado(self.pacote) == self.versao:
                tc.notify("Pacote instalado", "%s %s foi instalado." % (self.pacote, self.versao))
            else:
                tc.notify("A instalação não terminou",
                          "%s não foi instalado. Veja a mensagem no terminal." % self.pacote)
            self.destroy()
            return False
        GLib.timeout_add(700, fim)


def main():
    tc.load_css()
    if len(sys.argv) < 2:
        erro("Abra um arquivo .deb com dois cliques.")
        return
    deb = sys.argv[1]
    if deb.startswith("file://"):
        from urllib.parse import unquote, urlparse
        deb = unquote(urlparse(deb).path)
    if not os.path.isfile(deb) or not campo(deb, "Package"):
        erro("O arquivo não é um pacote .deb válido:\n%s" % deb)
        return
    j = Janela(deb)
    j.connect("destroy", Gtk.main_quit)
    j.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
