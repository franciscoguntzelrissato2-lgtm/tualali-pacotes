#!/usr/bin/python3
"""Loja Tualali - instala, atualiza e remove aplicativos (pacotes Debian via apt)."""
import json, subprocess, sys
sys.path.insert(0, "/usr/lib/tualali")
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib
from tualali_common import load_css, run, run_privileged_in_terminal

CATALOG = "/usr/share/tualali/store-catalog.json"


def installed(pkg):
    out = run(["dpkg-query", "-W", "-f=${Status}", pkg]) or ""
    return out.strip() == "install ok installed"


class Store(Gtk.Window):
    def __init__(self):
        super().__init__(title="Loja Tualali")
        self.set_default_size(860, 600)
        self.set_icon_name("system-software-install")
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for m in ("start", "end", "top", "bottom"):
            getattr(v, "set_margin_" + m)(16)
        top = Gtk.Box(spacing=8)
        self.search = Gtk.SearchEntry(placeholder_text="Pesquisar no catálogo ou em todos os pacotes Debian…")
        self.search.connect("activate", self.do_search)
        top.pack_start(self.search, True, True, 0)
        upd = Gtk.Button(label="Atualizar tudo")
        upd.connect("clicked", lambda *_: run_privileged_in_terminal("Atualizações", "tualali-update --install"))
        top.pack_start(upd, False, False, 0)
        v.pack_start(top, False, False, 0)
        self.listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        sc = Gtk.ScrolledWindow(vexpand=True); sc.add(self.listbox)
        v.pack_start(sc, True, True, 0)
        self.add(v)
        try:
            self.catalog = json.load(open(CATALOG))
        except (OSError, ValueError):
            self.catalog = []
        self.show_items(self.catalog)

    def show_items(self, items):
        for c in self.listbox.get_children():
            c.destroy()
        last_cat = None
        for it in items:
            if it.get("category") and it["category"] != last_cat:
                last_cat = it["category"]
                h = Gtk.Label(xalign=0); h.set_markup("<b>%s</b>" % GLib.markup_escape_text(last_cat))
                h.set_margin_top(10)
                self.listbox.add(h)
            r = Gtk.Box(spacing=12)
            r.set_margin_top(4); r.set_margin_bottom(4)
            r.pack_start(Gtk.Image.new_from_icon_name(it.get("icon", "application-x-executable"), Gtk.IconSize.DND), False, False, 0)
            txt = Gtk.Label(xalign=0, wrap=True)
            txt.set_markup("<b>%s</b>\n<small>%s</small>" % (GLib.markup_escape_text(it["name"]), GLib.markup_escape_text(it.get("description", ""))))
            r.pack_start(txt, True, True, 0)
            pkgs = it["packages"]
            if all(installed(p) for p in pkgs):
                b = Gtk.Button(label="Remover")
                b.get_style_context().add_class("destructive-action")
                b.connect("clicked", self.act, "remove", it)
            else:
                b = Gtk.Button(label="Instalar")
                b.get_style_context().add_class("suggested-action")
                b.connect("clicked", self.act, "install", it)
            r.pack_start(b, False, False, 0)
            self.listbox.add(r)
        if not items:
            self.listbox.add(Gtk.Label(label="Nada encontrado."))
        self.listbox.show_all()

    def do_search(self, entry):
        q = entry.get_text().strip().lower()
        if not q:
            return self.show_items(self.catalog)
        res = [i for i in self.catalog if q in (i["name"] + i.get("description", "")).lower()]
        names = {p for i in res for p in i["packages"]}
        out = run(["apt-cache", "search", "--names-only", q], 10) or ""
        for line in out.splitlines()[:60]:
            pkg, _, desc = line.partition(" - ")
            if pkg not in names:
                res.append({"name": pkg, "description": desc, "packages": [pkg], "icon": "package-x-generic", "category": "Pacotes Debian"})
        self.show_items(res)

    def act(self, _b, action, it):
        pkgs = " ".join(it["packages"])
        pre = it.get("pre", "")
        if action == "install":
            cmd = "%s apt-get update && apt-get install -y %s" % (pre + " &&" if pre else "", pkgs)
        else:
            cmd = "apt-get remove -y %s" % pkgs
        p = run_privileged_in_terminal("Loja Tualali", cmd + " && echo && echo 'Concluído. Pode fechar esta janela.'")
        if p:
            GLib.timeout_add(1500, self.wait, p)

    def wait(self, p):
        if p.poll() is None:
            return True
        self.do_search(self.search)
        return False


if __name__ == "__main__":
    load_css()
    w = Store(); w.connect("destroy", Gtk.main_quit); w.show_all(); Gtk.main()
