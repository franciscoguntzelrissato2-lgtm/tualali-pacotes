#!/usr/bin/env python3
"""Empacotador Tualali (nucleo): transforma um programa do Windows (.exe/.msi) num pacote .deb.

Dois jeitos:
- programa direto (um .exe que abre sozinho): gerar_deb()
- instalador (setup.exe / .msi): preparar_prefixo() -> retrato() -> rodar_instalador() ->
  procurar_programas() -> gerar_deb_instalado(). O instalador roda numa "garrafa" Wine temporaria;
  o .deb leva TUDO o que o instalador criou ou mudou (pasta do programa, DLLs em system32,
  Common Files...) e o registro do Windows dessa garrafa.

O .deb gerado contem:
- /opt/tualali-apps/<id>/drive_c/     arquivos do programa (no mesmo lugar do C: do Windows)
- /opt/tualali-apps/<id>/registro/    registro do Windows (so instaladores)
- /opt/tualali-apps/<id>/app.conf     nome, .exe principal, 32/64 bits, versao
- /opt/tualali-apps/<id>/abrir        iniciador: na 1a vez cria a garrafa do usuario em
                                      ~/.local/share/tualali-apps/<id>, copia os arquivos e o registro, e abre
- /usr/share/applications/<pacote>.desktop e o icone extraido do .exe
O Wine e compartilhado (pacote do Debian), instalado uma vez para todos os apps.

Linha de comando (tambem usada nos testes):
  empacotador_core.py --nome "Meu App" --exe programa.exe [--pasta pasta] --saida DIR
  empacotador_core.py --nome "Meu App" --instalador setup.exe --saida DIR [--silencioso ARG] [--principal N]
"""
import argparse
import datetime
import getpass
import os
import re
import shutil
import struct
import subprocess
import tempfile
import unicodedata

BASE = "/opt/tualali-apps"
SEM_MENU_DO_WINE = "winemenubuilder.exe=d"     # o Wine nao cria atalhos soltos no menu do Tualali
IGNORAR = re.compile(r"unins|uninstall|desinst|setup|install|update|updater|crash|report|helper|vcredist|"
                     r"dxsetup|redist|elevate|notification|launcher_?helper", re.I)

INICIADOR = r'''#!/bin/bash
# Iniciador gerado pelo Empacotador Tualali
D="$(dirname "$(readlink -f "$0")")"
. "$D/app.conf"
export WINEPREFIX="$HOME/.local/share/tualali-apps/$ID"
export WINEDEBUG=-all
export WINEDLLOVERRIDES="winemenubuilder.exe=d"
LOG="$HOME/.local/share/tualali-apps/$ID.log"
mkdir -p "$HOME/.local/share/tualali-apps"
aviso() { zenity --error --title="$NOME" --text="$1" 2>/dev/null || notify-send "$NOME" "$1"; }

if ! command -v wine >/dev/null 2>&1; then
  if zenity --question --title="$NOME" --text="Para abrir $NOME é preciso instalar o Wine (programas do Windows).\nInstalar agora? (precisa de internet)" 2>/dev/null; then
    pkexec sh -c 'dpkg --add-architecture i386 && apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y wine wine64 wine32:i386' \
      || { aviso "Não foi possível instalar o Wine."; exit 1; }
  else exit 1; fi
fi
if [ "$BITS" = 32 ] && ! dpkg-query -W -f='${Status}' wine32:i386 2>/dev/null | grep -q 'ok installed'; then
  if zenity --question --title="$NOME" --text="$NOME é um programa de 32 bits e precisa do Wine 32 bits.\nInstalar agora? (precisa de internet)" 2>/dev/null; then
    pkexec sh -c 'dpkg --add-architecture i386 && apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y wine32:i386' \
      || { aviso "Não foi possível instalar o Wine 32 bits."; exit 1; }
  else exit 1; fi
fi

preparar() {
  echo "# Preparando $NOME pela primeira vez…"
  if [ ! -d "$WINEPREFIX/drive_c" ]; then
    wineboot -i >>"$LOG" 2>&1
    wine reg add 'HKCU\Software\Wine' /v Version /d win10 /f >>"$LOG" 2>&1
  fi
  wineserver -w
  EU="$(id -un)"
  if [ -n "$USUARIO" ] && [ "$USUARIO" != "$EU" ] && [ -d "$D/drive_c/users/$USUARIO" ]; then
    # o programa foi instalado por outro usuario: a pasta dele vira a pasta deste usuario
    ( cd "$D/drive_c" && tar --exclude="./users/$USUARIO" -cf - . ) | ( cd "$WINEPREFIX/drive_c" && tar -xf - )
    mkdir -p "$WINEPREFIX/drive_c/users/$EU"
    cp -a "$D/drive_c/users/$USUARIO/." "$WINEPREFIX/drive_c/users/$EU/"
  else
    cp -a "$D/drive_c/." "$WINEPREFIX/drive_c/"
  fi
  if [ -d "$D/registro" ]; then
    wineserver -k 2>/dev/null; wineserver -w
    python3 - "$D/registro" "$WINEPREFIX" "$USUARIO" "$EU" "$HOME" <<'PY' >>"$LOG" 2>&1
import os, re, sys
orig, destino, de, para, casa = sys.argv[1:6]
for nome in ("system.reg", "user.reg", "userdef.reg"):
    p = os.path.join(orig, nome)
    if not os.path.exists(p):
        continue
    t = open(p, encoding="utf-8", errors="surrogateescape").read()
    if de and de != para:
        t = re.sub(r"(\\\\users\\\\)" + re.escape(de) + r'(?=\\\\|")', lambda m: m.group(1) + para, t, flags=re.I)
        t = t.replace("/home/" + de + "/", casa.rstrip("/") + "/")
    open(os.path.join(destino, nome), "w", encoding="utf-8", errors="surrogateescape").write(t)
PY
  fi
  echo "$VERSAO" > "$WINEPREFIX/.tualali-versao"
}

if [ ! -f "$WINEPREFIX/.tualali-versao" ] || [ "$(cat "$WINEPREFIX/.tualali-versao")" != "$VERSAO" ]; then
  if [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && command -v zenity >/dev/null; then
    preparar | zenity --progress --pulsate --auto-close --no-cancel --title="$NOME" 2>/dev/null
  else
    preparar >/dev/null
  fi
fi
cd "$WINEPREFIX/drive_c/$(dirname "$EXE")" || { aviso "Os arquivos de $NOME não foram encontrados."; exit 1; }
exec wine "$(basename "$EXE")" "$@" 2>>"$LOG"
'''


def slug(texto):
    t = unicodedata.normalize("NFKD", texto).encode("ascii", "ignore").decode().lower()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    return (t or "app")[:40]


def bits_do_exe(caminho):
    """32 ou 64 conforme o cabecalho PE do .exe (None se nao for um .exe do Windows)."""
    try:
        with open(caminho, "rb") as f:
            if f.read(2) != b"MZ":
                return None
            f.seek(0x3C)
            pe = struct.unpack("<I", f.read(4))[0]
            f.seek(pe)
            if f.read(4) != b"PE\0\0":
                return None
            maquina = struct.unpack("<H", f.read(2))[0]
    except (OSError, struct.error):
        return None
    return 64 if maquina in (0x8664, 0xAA64) else 32


def parece_instalador(caminho):
    """True se o arquivo parece um instalador (msi, NSIS, Inno Setup, InstallShield...)."""
    base = os.path.basename(caminho).lower()
    if base.endswith(".msi") or re.search(r"setup|install|instalador", base):
        return True
    try:
        with open(caminho, "rb") as f:
            dados = f.read(4 * 1024 * 1024)
    except OSError:
        return False
    return any(m in dados for m in (b"Nullsoft", b"NullsoftInst", b"Inno Setup", b"InstallShield",
                                    b"Wise Installation", b"Setup Factory", b"WixBundle", b"Advanced Installer"))


def extrair_icone(exe, destino_png):
    """Extrai o maior icone do .exe (icoutils). Devolve True se conseguiu."""
    if not shutil.which("wrestool") or not shutil.which("icotool"):
        return False
    with tempfile.TemporaryDirectory() as tmp:
        try:
            subprocess.run(["wrestool", "-x", "-t", "14", "-o", tmp, exe],
                           capture_output=True, timeout=60)
            for ico in os.listdir(tmp):
                if ico.endswith(".ico"):
                    subprocess.run(["icotool", "-x", "-o", tmp, os.path.join(tmp, ico)],
                                   capture_output=True, timeout=60)
        except (OSError, subprocess.SubprocessError):
            return False
        pngs = [os.path.join(tmp, p) for p in os.listdir(tmp) if p.endswith(".png")]
        if not pngs:
            return False

        def tamanho(p):
            m = re.search(r"_(\d+)x(\d+)x(\d+)\.png$", p)
            return (int(m.group(1)), int(m.group(3))) if m else (0, os.path.getsize(p))
        shutil.copy(max(pngs, key=tamanho), destino_png)
    return True


# ------------------------------------------------------------------ instaladores
def ambiente_wine(prefixo):
    return dict(os.environ, WINEPREFIX=prefixo, WINEDEBUG="-all", WINEDLLOVERRIDES=SEM_MENU_DO_WINE)


def wine32_instalado():
    r = subprocess.run(["dpkg-query", "-W", "-f=${Status}", "wine32:i386"], capture_output=True, text=True)
    return "ok installed" in r.stdout


def preparar_prefixo(prefixo, log=print):
    """Cria uma garrafa Wine limpa (Windows 10) so para rodar o instalador."""
    shutil.rmtree(prefixo, ignore_errors=True)
    os.makedirs(prefixo)
    env = ambiente_wine(prefixo)
    log("Preparando o Wine… (na primeira vez pode levar alguns minutos)")
    subprocess.run(["wineboot", "-i"], env=env, capture_output=True)
    subprocess.run(["wine", "reg", "add", r"HKCU\Software\Wine", "/v", "Version", "/d", "win10", "/f"],
                   env=env, capture_output=True)
    subprocess.run(["wineserver", "-w"], env=env, capture_output=True)
    if not os.path.isdir(os.path.join(prefixo, "drive_c", "windows")):
        raise RuntimeError("O Wine não conseguiu preparar a garrafa. Veja se o Wine está instalado.")
    # As pastas Desktop, Documentos etc. da garrafa apontam para as pastas reais do usuario.
    # Durante a instalacao viram pastas comuns, para o instalador nao espalhar atalhos na sua area de trabalho.
    usuarios = os.path.join(prefixo, "drive_c", "users")
    for u in os.listdir(usuarios):
        pu = os.path.join(usuarios, u)
        if os.path.isdir(pu):
            for n in os.listdir(pu):
                p = os.path.join(pu, n)
                if os.path.islink(p):
                    os.remove(p)
                    os.makedirs(p)
    return prefixo


def retrato(prefixo):
    """{caminho relativo ao drive_c: (tamanho, data)} de todos os arquivos da garrafa."""
    c = os.path.join(prefixo, "drive_c")
    r = {}
    for raiz, _d, arquivos in os.walk(c):
        for n in arquivos:
            p = os.path.join(raiz, n)
            try:
                s = os.lstat(p)
            except OSError:
                continue
            r[os.path.relpath(p, c)] = (s.st_size, s.st_mtime_ns)
    return r


def rodar_instalador(inst, prefixo, log=print, silencioso=None):
    """Roda o instalador na garrafa e espera ele (e tudo o que ele abriu) terminar."""
    env = ambiente_wine(prefixo)
    log("Siga as etapas do instalador que abriu. Quando ele terminar, eu continuo sozinho.")
    if inst.lower().endswith(".msi"):
        cmd = ["wine", "msiexec", "/i", inst] + (["/qn"] if silencioso is not None else [])
    else:
        cmd = ["wine", inst] + ([silencioso] if silencioso else [])
    r = subprocess.run(cmd, env=env, capture_output=True, text=True, errors="replace",
                       cwd=os.path.dirname(os.path.abspath(inst)))
    subprocess.run(["wineserver", "-w"], env=env, capture_output=True)
    return r.returncode, (r.stderr or "")[-2000:]


def _alvo_do_atalho(lnk):
    """Caminho do Windows para onde aponta um atalho .lnk (LocalBasePath), ou None."""
    try:
        with open(lnk, "rb") as f:
            d = f.read(1024 * 1024)
        if len(d) < 0x4C or struct.unpack("<I", d[:4])[0] != 0x4C:
            return None
        flags = struct.unpack("<I", d[0x14:0x18])[0]
        pos = 0x4C
        if flags & 0x01:                                        # HasLinkTargetIDList
            pos += 2 + struct.unpack("<H", d[pos:pos + 2])[0]
        if not flags & 0x02:                                    # HasLinkInfo
            return None
        info = pos
        cab = struct.unpack("<I", d[info + 4:info + 8])[0]
        iflags = struct.unpack("<I", d[info + 8:info + 12])[0]
        if not iflags & 0x01:                                   # VolumeIDAndLocalBasePath
            return None
        if cab >= 0x24:                                         # caminho em Unicode
            off = struct.unpack("<I", d[info + 0x1C:info + 0x20])[0]
            fim = d.find(b"\0\0", info + off)
            while fim != -1 and (fim - info - off) % 2:
                fim = d.find(b"\0\0", fim + 1)
            return d[info + off:fim].decode("utf-16-le", "replace")
        off = struct.unpack("<I", d[info + 0x10:info + 0x14])[0]
        return d[info + off:d.index(b"\0", info + off)].decode("cp1252", "replace")
    except (OSError, struct.error, ValueError):
        return None


def caminho_na_garrafa(prefixo, caminho_windows):
    """C:\\Program Files\\X\\x.exe -> caminho real dentro da garrafa (sem diferenciar maiusculas)."""
    m = re.match(r"^[cC]:[\\/](.*)$", caminho_windows or "")
    if not m:
        return None
    atual = os.path.join(prefixo, "drive_c")
    for parte in [p for p in re.split(r"[\\/]+", m.group(1)) if p]:
        try:
            nomes = os.listdir(atual)
        except OSError:
            return None
        achado = next((n for n in nomes if n.lower() == parte.lower()), None)
        if achado is None:
            return None
        atual = os.path.join(atual, achado)
    return atual if os.path.isfile(atual) else None


def procurar_programas(prefixo):
    """Programas instalados: [(rotulo, caminho do .exe)]. Primeiro os atalhos que o instalador
    criou (menu Iniciar / area de trabalho); depois os outros .exe, do maior para o menor."""
    c = os.path.join(prefixo, "drive_c")
    vistos, lista = set(), []
    lnks = []
    for raiz, pastas, arquivos in os.walk(c):
        if raiz == c and "windows" in [p.lower() for p in pastas]:
            pastas[:] = [p for p in pastas if p.lower() != "windows"]      # nao entra no C:\windows
        for n in arquivos:
            if n.lower().endswith(".lnk"):
                lnks.append(os.path.join(raiz, n))
    for lnk in sorted(lnks):
        alvo = caminho_na_garrafa(prefixo, _alvo_do_atalho(lnk))
        nome = os.path.splitext(os.path.basename(lnk))[0]
        if alvo and alvo.lower().endswith(".exe") and not IGNORAR.search(os.path.basename(alvo)) \
                and not IGNORAR.search(nome) and alvo not in vistos:
            vistos.add(alvo)
            lista.append((nome, alvo))
    outros = []
    for base in ("Program Files", "Program Files (x86)", "users"):
        for raiz, _d, arquivos in os.walk(os.path.join(c, base)):
            r = raiz.lower()
            if any(x in r for x in ("common files", "internet explorer", "windows media player", "windows nt",
                                    "windows photo viewer", "microsoft.net", os.sep + "temp")):
                continue
            for a in arquivos:
                p = os.path.join(raiz, a)
                if a.lower().endswith(".exe") and not IGNORAR.search(a) and p not in vistos:
                    outros.append((os.path.getsize(p), p))
    for _t, p in sorted(outros, reverse=True):
        lista.append((os.path.relpath(p, c).replace(os.sep, "\\"), p))
    return lista


EXCLUIR = re.compile(r"^(windows/temp/|users/[^/]+/(temp|appdata/local/temp|desktop|área de trabalho|"
                     r"appdata/local/microsoft/windows/(inetcache|webcache))(/|$)|users/public/desktop/)", re.I)


def mudancas(prefixo, antes):
    """Arquivos que o instalador criou ou mudou (relativos ao drive_c)."""
    depois = retrato(prefixo)
    return sorted(p for p, info in depois.items()
                  if antes.get(p) != info and not EXCLUIR.match(p.replace(os.sep, "/")))


# ------------------------------------------------------------------ geracao do .deb
def _empacotar(nome, exe_rel, bits, icone_de, montar, registro=None, usuario="", saida=".", versao=None,
               log=print):
    ident = slug(nome)
    pacote = "tualali-app-" + ident
    versao = versao or "1.0+" + datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    with tempfile.TemporaryDirectory() as st:
        app = os.path.join(st, BASE.lstrip("/"), ident)
        drive = os.path.join(app, "drive_c")
        os.makedirs(drive)
        log("Copiando os arquivos do programa…")
        montar(drive, ident)
        if registro:
            os.makedirs(os.path.join(app, "registro"))
            for n in ("system.reg", "user.reg", "userdef.reg"):
                if os.path.exists(os.path.join(registro, n)):
                    shutil.copy2(os.path.join(registro, n), os.path.join(app, "registro", n))
        with open(os.path.join(app, "app.conf"), "w") as f:
            f.write("NOME=%s\nID=%s\nEXE=%s\nBITS=%d\nVERSAO=%s\nUSUARIO=%s\n" % (
                _q(nome), _q(ident), _q(exe_rel), bits, _q(versao), _q(usuario)))
        with open(os.path.join(app, "abrir"), "w") as f:
            f.write(INICIADOR)

        log("Extraindo o ícone…")
        icones = os.path.join(st, "usr/share/icons/hicolor/256x256/apps")
        os.makedirs(icones)
        icone = pacote if extrair_icone(icone_de, os.path.join(icones, pacote + ".png")) else "wine"
        if icone == "wine":
            os.rmdir(icones)

        apps = os.path.join(st, "usr/share/applications")
        os.makedirs(apps)
        with open(os.path.join(apps, pacote + ".desktop"), "w") as f:
            f.write("[Desktop Entry]\nType=Application\nName=%s\nComment=Programa do Windows (Empacotador Tualali)\n"
                    "Exec=%s/%s/abrir %%F\nIcon=%s\nTerminal=false\nCategories=Wine;\n"
                    "StartupWMClass=%s\n" % (nome, BASE, ident, icone, os.path.basename(exe_rel).lower()))

        deb = os.path.join(st, "DEBIAN")
        os.makedirs(deb)
        kb = sum(os.path.getsize(os.path.join(r, n)) for r, _, fs in os.walk(st) for n in fs
                 if not os.path.islink(os.path.join(r, n))) // 1024 + 1
        with open(os.path.join(deb, "control"), "w") as f:
            f.write("Package: %s\nVersion: %s\nArchitecture: all\n"
                    "Maintainer: Empacotador Tualali <empacotador@tualali.local>\n"
                    "Installed-Size: %d\nDepends: wine, zenity, python3\nRecommends: wine64\nSection: otherosfs\n"
                    "Priority: optional\nDescription: %s (programa do Windows)\n"
                    " Gerado pelo Empacotador Tualali: contem o programa original do Windows\n"
                    " e a configuracao do Wine para abri-lo como um app normal.\n"
                    % (pacote, versao, kb, nome))
        # permissoes: pastas 755, arquivos 644, iniciador e programas executaveis
        for r, ds, fs in os.walk(st):
            for d in ds:
                if not os.path.islink(os.path.join(r, d)):
                    os.chmod(os.path.join(r, d), 0o755)
            for n in fs:
                p = os.path.join(r, n)
                if not os.path.islink(p):
                    os.chmod(p, 0o755 if n == "abrir" or n.lower().endswith((".exe", ".dll")) else 0o644)

        os.makedirs(saida, exist_ok=True)
        arquivo = os.path.join(os.path.abspath(saida), "%s_%s_all.deb" % (pacote, versao))
        log("Gerando o pacote .deb…")
        r = subprocess.run(["dpkg-deb", "--root-owner-group", "-Zxz", "--build", st, arquivo],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("dpkg-deb falhou: " + r.stderr.strip())
    return arquivo


def gerar_deb(nome, exe, pasta=None, saida=".", versao=None, log=print):
    """Programa direto. exe: o .exe principal. pasta: pasta inteira do programa (opcional)."""
    exe = os.path.abspath(exe)
    nome = " ".join(str(nome).split())[:60] or "Programa"
    if pasta:
        pasta = os.path.abspath(pasta)
        rel = os.path.relpath(exe, pasta)
        if rel.startswith(".."):
            raise ValueError("O .exe principal precisa estar dentro da pasta do programa.")
    else:
        rel = os.path.basename(exe)
    bits = bits_do_exe(exe)
    if bits is None:
        raise ValueError("O arquivo não é um programa do Windows (.exe) válido.")

    def montar(drive, ident):
        destino = os.path.join(drive, "Tualali", ident)
        if pasta:
            shutil.copytree(pasta, destino, symlinks=True)
        else:
            os.makedirs(destino)
            shutil.copy2(exe, os.path.join(destino, rel))
    ident = slug(nome)
    return _empacotar(nome, "Tualali/%s/%s" % (ident, rel.replace(os.sep, "/")), bits, exe, montar,
                      saida=saida, versao=versao, log=log)


def gerar_deb_instalado(nome, prefixo, exe, antes, saida=".", versao=None, log=print):
    """Instalador: leva tudo o que mudou na garrafa desde o retrato 'antes' + o registro."""
    nome = " ".join(str(nome).split())[:60] or "Programa"
    c = os.path.join(prefixo, "drive_c")
    exe = os.path.abspath(exe)
    rel = os.path.relpath(exe, c)
    if rel.startswith(".."):
        raise ValueError("O programa principal precisa estar dentro da garrafa do Wine.")
    bits = bits_do_exe(exe)
    if bits is None:
        raise ValueError("O programa escolhido não é um .exe válido.")
    lista = mudancas(prefixo, antes)
    if rel not in lista:
        lista.append(rel)
    log("O instalador criou ou mudou %d arquivos." % len(lista))

    def montar(drive, _ident):
        for r in lista:
            o, d = os.path.join(c, r), os.path.join(drive, r)
            os.makedirs(os.path.dirname(d), exist_ok=True)
            if os.path.islink(o):
                os.symlink(os.readlink(o), d)
            else:
                shutil.copy2(o, d)
    return _empacotar(nome, rel.replace(os.sep, "/"), bits, exe, montar, registro=prefixo,
                      usuario=getpass.getuser(), saida=saida, versao=versao, log=log)


def _q(v):
    """Valor seguro para o app.conf (lido pelo bash com '.')."""
    return "'" + str(v).replace("'", "'\\''") + "'"


def main():
    a = argparse.ArgumentParser(description="Empacotador Tualali: .exe -> .deb")
    a.add_argument("--nome", required=True)
    a.add_argument("--exe")
    a.add_argument("--pasta")
    a.add_argument("--instalador")
    a.add_argument("--silencioso", help="argumento para instalar sem perguntas (ex.: /S)")
    a.add_argument("--principal", type=int, default=0, help="qual programa encontrado usar (0 = o 1o)")
    a.add_argument("--saida", default=".")
    o = a.parse_args()
    if o.instalador:
        prefixo = tempfile.mkdtemp(prefix="tualali-empacotador-")
        try:
            preparar_prefixo(prefixo)
            antes = retrato(prefixo)
            rc, erro = rodar_instalador(o.instalador, prefixo, silencioso=o.silencioso)
            progs = procurar_programas(prefixo)
            for i, (rot, p) in enumerate(progs[:10]):
                print("programa %d: %s -> %s" % (i, rot, os.path.relpath(p, prefixo)))
            if not progs:
                raise SystemExit("nenhum programa instalado (instalador saiu com %s) %s" % (rc, erro))
            print(gerar_deb_instalado(o.nome, prefixo, progs[o.principal][1], antes, o.saida))
        finally:
            shutil.rmtree(prefixo, ignore_errors=True)
    else:
        print(gerar_deb(o.nome, o.exe, o.pasta, o.saida))


if __name__ == "__main__":
    main()
