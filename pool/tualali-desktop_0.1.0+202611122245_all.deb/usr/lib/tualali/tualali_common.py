"""Funcoes compartilhadas pelos aplicativos do Tualali OS."""
import subprocess
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib

CSS_PATH = "/usr/share/tualali/tualali.css"


def load_css():
    prov = Gtk.CssProvider()
    try:
        prov.load_from_path(CSS_PATH)
    except GLib.Error as e:
        print("CSS:", e)
        return
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


def run(cmd, timeout=4):
    """Executa um comando e devolve stdout (ou None em caso de erro)."""
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
    except (OSError, subprocess.SubprocessError):
        return None


def spawn(cmd, notify_fail=None):
    """Executa um comando em segundo plano sem travar a interface."""
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        if notify_fail:
            notify("Tualali OS", notify_fail)
        return None
    if notify_fail:
        def check():
            rc = p.poll()
            if rc is None:
                return True
            if rc != 0:
                notify("Tualali OS", notify_fail)
            return False
        GLib.timeout_add(500, check)
    return p


def notify(title, body):
    try:
        subprocess.Popen(["notify-send", "-i", "tualali-logo", title, body])
    except OSError:
        pass


def run_privileged_in_terminal(title, shell_cmd):
    """Abre um terminal executando um comando com privilegios (pkexec)."""
    script = shell_cmd + "; echo; echo 'Pressione Enter para fechar.'; read x"
    return spawn(["gnome-terminal", "--wait", "--title", title, "--",
                  "pkexec", "sh", "-c", script])
