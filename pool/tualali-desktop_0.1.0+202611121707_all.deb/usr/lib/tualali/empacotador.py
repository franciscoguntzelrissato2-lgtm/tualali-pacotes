#!/usr/bin/env python3
"""Empacotador Tualali: dois cliques num .exe -> app .deb (programa original + Wine configurado)."""
import datetime
import os
import re
import shutil
import subprocess
import sys
import threading
import urllib.parse

sys.path.insert(0, "/usr/lib/tualali")
import tualali_common as tc  # noqa: E402
from tualali_common import Gtk, GLib  # noqa: E402
import empacotador_core as core  # noqa: E402

CACHE = os.path.join(os.path.expanduser("~"), ".cache", "tualali-empacotador")
LOG = os.path.join(CACHE, "ultimo.log")
INSTALAR_WINE = ("dpkg --add-architecture i386 && apt-get update && "
                 "DEBIAN_FRONTEND=noninteractive apt-get install -y wine wine64 wine32:i386")


def pasta_saida():
    """Os apps criados vao para a pasta Downloads (facil de achar)."""
    d = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) or os.path.expanduser("~/Downloads")
    return d


def nome_sugerido(caminho):
    n = os.path.splitext(os.path.basename(caminho))[0]
    n = re.sub(r"(?i)v?\d+(\.\d+)+", " ", n)            # versoes: 3.0.21, v1.2
    n = re.sub(r"[_\.\-]+", " ", n)
    n = re.sub(r"(?i)\b(setup|install(er)?|instalador|x64|x86|amd64|win(32|64)?|portable|full|\d+)\b", " ", n)
    palavras = n.split()
    n = " ".join(p if any(c.isupper() for c in p) else p.capitalize() for p in palavras)
    return n or "Meu Programa"


class Empacotador(Gtk.Window):
    def __init__(self, arquivo=None):
        super().__init__(title="Empacotador Tualali")
        self.set_default_size(580, 440)
        self.set_border_width(18)
        self.set_icon_name("tualali-logo")
        self.caixa = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(self.caixa)
        os.makedirs(CACHE, exist_ok=True)

        t = Gtk.Label(xalign=0)
        t.set_markup("<span size='x-large' weight='bold'>Empacotador Tualali</span>")
        self.caixa.pack_start(t, False, False, 0)
        s = Gtk.Label(xalign=0, label="Transforma um programa do Windows (.exe ou .msi) num app do Tualali. "
                                       "Funciona com o próprio programa e com instaladores (setup). "
                                       "O app pronto é instalado e aparece no menu de aplicativos.")
        s.set_line_wrap(True)
        self.caixa.pack_start(s, False, False, 0)

        grade = Gtk.Grid(column_spacing=10, row_spacing=8)
        self.caixa.pack_start(grade, False, False, 6)
        grade.attach(Gtk.Label(label="Arquivo:", xalign=1), 0, 0, 1, 1)
        self.escolher = Gtk.FileChooserButton(title="Escolha o .exe", action=Gtk.FileChooserAction.OPEN)
        filtro = Gtk.FileFilter()
        filtro.set_name("Programas do Windows (.exe, .msi)")
        for p in ("*.exe", "*.EXE", "*.msi", "*.MSI"):
            filtro.add_pattern(p)
        self.escolher.add_filter(filtro)
        self.escolher.set_hexpand(True)
        self.escolher.connect("file-set", self.arquivo_escolhido)
        grade.attach(self.escolher, 1, 0, 1, 1)
        grade.attach(Gtk.Label(label="Nome do app:", xalign=1), 0, 1, 1, 1)
        self.nome = Gtk.Entry()
        grade.attach(self.nome, 1, 1, 1, 1)

        self.r_prog = Gtk.RadioButton.new_with_label(None, "É o próprio programa (abre direto)")
        self.r_inst = Gtk.RadioButton.new_with_label_from_widget(
            self.r_prog, "É um instalador (setup): vou instalar e depois criar o app")
        self.caixa.pack_start(self.r_prog, False, False, 0)
        self.caixa.pack_start(self.r_inst, False, False, 0)

        self.status = Gtk.Label(xalign=0)
        self.status.set_line_wrap(True)
        self.status.set_selectable(True)
        self.caixa.pack_start(self.status, False, False, 6)
        self.giro = Gtk.Spinner()
        self.caixa.pack_start(self.giro, False, False, 0)

        botoes = Gtk.Box(spacing=8)
        self.caixa.pack_end(botoes, False, False, 0)
        self.criar = Gtk.Button(label="Criar app")
        self.criar.get_style_context().add_class("suggested-action")
        self.criar.connect("clicked", self.comecar)
        fechar = Gtk.Button(label="Fechar")
        fechar.connect("clicked", lambda *_: self.destroy())
        botoes.pack_end(self.criar, False, False, 0)
        botoes.pack_end(fechar, False, False, 0)

        if arquivo:
            self.escolher.set_filename(arquivo)
            self.arquivo_escolhido()

    # ---------- interface ----------
    def arquivo_escolhido(self, *_):
        f = self.escolher.get_filename() or ""
        self.nome.set_text(nome_sugerido(f))
        if core.parece_instalador(f):
            self.r_inst.set_active(True)
        else:
            self.r_prog.set_active(True)
        self.r_prog.set_sensitive(not f.lower().endswith(".msi"))

    def registrar(self, texto):
        try:
            with open(LOG, "a") as f:
                f.write("%s %s\n" % (datetime.datetime.now().strftime("%H:%M:%S"), texto))
        except OSError:
            pass

    def msg(self, texto, girando=None):
        self.registrar(texto)

        def f():
            self.status.set_text(texto)
            if girando is True:
                self.giro.start()
            elif girando is False:
                self.giro.stop()
            return False
        GLib.idle_add(f)

    def ocupado(self, sim):
        GLib.idle_add(lambda: (self.criar.set_sensitive(not sim), False)[1])

    def erro(self, texto):
        """Erro bem visivel (janela), alem da linha de status e do registro."""
        self.msg("Erro: " + texto, False)
        self.ocupado(False)

        def f():
            d = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.ERROR,
                                  buttons=Gtk.ButtonsType.OK, text="Não foi possível criar o app")
            d.format_secondary_text("%s\n\nDetalhes: %s" % (texto, LOG))
            d.run()
            d.destroy()
            return False
        GLib.idle_add(f)

    def comecar(self, _b):
        f = self.escolher.get_filename()
        if not f or not os.path.isfile(f):
            self.msg("Escolha primeiro um arquivo .exe ou .msi.")
            return
        try:
            with open(LOG, "w") as log:
                log.write("Empacotador Tualali - %s\nArquivo: %s\n" % (datetime.datetime.now(), f))
        except OSError:
            pass
        if self.r_inst.get_active():
            self.instalar_primeiro(f)
        else:
            self.ocupado(True)
            threading.Thread(target=self.gerar, args=(f,), daemon=True).start()

    # ---------- programa direto ----------
    def gerar(self, exe):
        self.msg("Criando o app…", True)
        try:
            deb = core.gerar_deb(self.nome.get_text(), exe, None, pasta_saida(), log=lambda t: self.msg(t, True))
        except Exception as e:  # noqa: BLE001 - mostrar qualquer erro ao usuario
            self.erro(str(e))
            return
        self.terminou(deb)

    def terminou(self, deb):
        self.msg("Pronto! O app foi salvo em Downloads:\n%s" % deb, False)
        self.ocupado(False)
        GLib.idle_add(self.pronto, deb)

    def pronto(self, deb):
        d = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.NONE, text="App criado!")
        d.format_secondary_text("O arquivo %s foi salvo na pasta Downloads.\n\n"
                                "Clique em \"Instalar agora\" para o app aparecer no menu de aplicativos. "
                                "Você também pode levar esse arquivo para outros computadores com o Tualali."
                                % os.path.basename(deb))
        d.add_button("Mostrar o arquivo", 1)
        b = d.add_button("Instalar agora", 2)
        b.get_style_context().add_class("suggested-action")
        d.set_default_response(2)
        r = d.run()
        d.destroy()
        if r == 1:
            uri = "file://" + urllib.parse.quote(deb)
            if subprocess.run(["gdbus", "call", "--session", "--dest", "org.freedesktop.FileManager1",
                               "--object-path", "/org/freedesktop/FileManager1", "--method",
                               "org.freedesktop.FileManager1.ShowItems", "['%s']" % uri, ""],
                              capture_output=True).returncode != 0:
                tc.spawn(["xdg-open", os.path.dirname(deb)])
        elif r == 2:
            tc.spawn(["/usr/bin/python3", "/usr/lib/tualali/instalar-deb.py", deb])
        return False

    # ---------- instalador (setup.exe / .msi) ----------
    def precisa_wine32(self, inst):
        return inst.lower().endswith(".msi") or core.bits_do_exe(inst) != 64

    def instalar_primeiro(self, inst):
        falta = not shutil.which("wine") or (self.precisa_wine32(inst) and not core.wine32_instalado())
        if falta:
            d = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.QUESTION,
                                  buttons=Gtk.ButtonsType.YES_NO,
                                  text="Para rodar o instalador é preciso o Wine")
            d.format_secondary_text("O Wine roda programas do Windows. Instalar agora? Precisa de internet e da "
                                    "senha de administrador (uns 300 MB, só na primeira vez).")
            r = d.run()
            d.destroy()
            if r != Gtk.ResponseType.YES:
                return
            self.msg("Instalando o Wine… siga a janela do terminal.", True)
            self.ocupado(True)
            p = tc.run_privileged_in_terminal("Instalando o Wine", INSTALAR_WINE)

            def esperar():
                if p and p.poll() is None:
                    return True
                self.ocupado(False)
                if shutil.which("wine") and (not self.precisa_wine32(inst) or core.wine32_instalado()):
                    self.instalar_primeiro(inst)
                else:
                    self.erro("O Wine não foi instalado. Verifique a internet e tente de novo.")
                return False
            GLib.timeout_add(1000, esperar)
            return
        self.ocupado(True)
        threading.Thread(target=self.rodar_instalador, args=(inst,), daemon=True).start()

    def rodar_instalador(self, inst):
        prefixo = os.path.join(CACHE, "garrafa-" + core.slug(self.nome.get_text()))
        try:
            core.preparar_prefixo(prefixo, log=lambda t: self.msg(t, True))
            antes = core.retrato(prefixo)
            rc, saida = core.rodar_instalador(inst, prefixo, log=lambda t: self.msg(t, True))
            self.registrar("instalador terminou (codigo %s)\n%s" % (rc, saida))
            achados = core.procurar_programas(prefixo)
        except Exception as e:  # noqa: BLE001
            self.erro(str(e))
            return
        if not achados:
            self.erro("O instalador terminou, mas não encontrei nenhum programa instalado. "
                      "Ele foi até o fim? (código %s)" % rc)
            shutil.rmtree(prefixo, ignore_errors=True)
            return
        GLib.idle_add(self.escolher_principal, prefixo, antes, achados)

    def escolher_principal(self, prefixo, antes, achados):
        self.msg("Instalação concluída. Escolha qual é o programa principal.", False)
        d = Gtk.Dialog(title="Qual é o programa principal?", transient_for=self)
        d.add_button("Cancelar", Gtk.ResponseType.CANCEL)
        b = d.add_button("Criar app", Gtk.ResponseType.OK)
        b.get_style_context().add_class("suggested-action")
        lista = Gtk.ComboBoxText()
        for rotulo, _p in achados[:40]:
            lista.append_text(rotulo)
        lista.set_active(0)
        area = d.get_content_area()
        area.set_spacing(8)
        area.set_border_width(12)
        area.add(Gtk.Label(label="Programas instalados (os atalhos criados pelo instalador aparecem primeiro):",
                           xalign=0))
        area.add(lista)
        d.show_all()
        r = d.run()
        i = lista.get_active()
        d.destroy()
        if r != Gtk.ResponseType.OK or i < 0:
            shutil.rmtree(prefixo, ignore_errors=True)
            self.msg("Cancelado.", False)
            self.ocupado(False)
            return False
        threading.Thread(target=self.gerar_instalado, args=(prefixo, achados[i][1], antes), daemon=True).start()
        return False

    def gerar_instalado(self, prefixo, exe, antes):
        self.msg("Criando o app…", True)
        try:
            deb = core.gerar_deb_instalado(self.nome.get_text(), prefixo, exe, antes, pasta_saida(),
                                           log=lambda t: self.msg(t, True))
        except Exception as e:  # noqa: BLE001
            self.erro(str(e))
            return
        finally:
            shutil.rmtree(prefixo, ignore_errors=True)
        self.terminou(deb)


def main():
    tc.load_css()
    arquivo = sys.argv[1] if len(sys.argv) > 1 else None
    if arquivo and arquivo.startswith("file://"):
        arquivo = urllib.parse.unquote(urllib.parse.urlparse(arquivo).path)
    j = Empacotador(arquivo)
    j.connect("destroy", Gtk.main_quit)
    j.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
